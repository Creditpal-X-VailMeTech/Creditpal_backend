-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 14, 2024 at 02:21 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `loan_app`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(500) NOT NULL,
  `admin_username` varchar(500) NOT NULL,
  `admin_pwd` varchar(500) NOT NULL,
  `auth_code` int(11) NOT NULL,
  `admin_main` varchar(500) NOT NULL,
  `admin_pic` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `admin_username`, `admin_pwd`, `auth_code`, `admin_main`, `admin_pic`) VALUES
(21, 'muolokwu', 'molo@gmial.com', '$2y$10$2HgFFVErqSI6Npva3NSvWO97U1fV8/554MXUAvZS5ZpWZ3SJcOqRS', 0, '', ''),
(22, 'Muolokwu', 'molo@gmail.com', '$2y$10$zCpttSUppI0Tn7oLlcysP.MVuhMUStdfdxomJJh/ds5fzCNOd7vCO', 0, '', ''),
(23, 'Muolokwu', 'egotakens@gmail.com', '$2y$10$c994lUfpsleEnFB418SyIeAbHdEbtGdpq/5dUqRBSYZGpVsj6uSuW', 0, '', 'LMS/LMS/image/admin_profile.svg'),
(24, 'Ifeani', 'obi@gmail.com', '$2y$10$QcuBGsY9rm0r2IfTjMKy6eONwhyNQD1fkn5/UnSih9qp6tx1meH0O', 0, '', 'LMS/LMS/image/admin_profile.svg'),
(25, 'Ifeani', 'obi@gmail.com', '$2y$10$QcuBGsY9rm0r2IfTjMKy6eONwhyNQD1fkn5/UnSih9qp6tx1meH0O', 0, '', 'LMS/LMS/image/admin_profile.svg'),
(26, 'Esther', 'es@gmail.com', '$2y$10$dYnmL7BnIKP8bZTKBa9dDuxLzvnqTPVQ7qGX4tOtR2vSYBHOQzbjC', 0, '', 'LMS/LMS/image/admin_profile.svg'),
(27, 'Esther', 'es@gmail.com', '$2y$10$dYnmL7BnIKP8bZTKBa9dDuxLzvnqTPVQ7qGX4tOtR2vSYBHOQzbjC', 0, '', 'LMS/LMS/image/admin_profile.svg');

-- --------------------------------------------------------

--
-- Table structure for table `bank_transfer`
--

CREATE TABLE `bank_transfer` (
  `id` int(11) NOT NULL,
  `account_user` varchar(500) NOT NULL,
  `account_number` int(11) NOT NULL,
  `bank` varchar(500) NOT NULL,
  `amount` int(11) NOT NULL,
  `note` varchar(500) DEFAULT NULL,
  `transfer_status` int(11) NOT NULL,
  `transfer_date` datetime DEFAULT NULL,
  `ref` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bank_transfer`
--

INSERT INTO `bank_transfer` (`id`, `account_user`, `account_number`, `bank`, `amount`, `note`, `transfer_status`, `transfer_date`, `ref`) VALUES
(1, 'loans@gmail.com', 1111, 'zenith bank', 11, 'pay', 0, '2024-11-06 01:59:36', ''),
(2, 'loans@gmail.com', 1111, 'zenith bank', 100, 'pay', 0, '2024-11-06 02:18:29', ''),
(3, 'loans@gmail.com', 1111, 'zenith bank', 100, 'pay', 0, '2024-11-06 02:19:59', ''),
(4, 'loans@gmail.com', 1111, 'zenith bank', 100, 'pay', 0, '2024-11-06 02:25:36', ''),
(5, 'loans@gmail.com', 1111, 'zenith bank', 100, 'pay', 0, '2024-11-06 02:30:48', ''),
(6, 'loans@gmail.com', 1111, 'zenith bank', 100, 'pay', 0, '2024-11-06 02:33:10', ''),
(7, 'loans@gmail.com', 1111, 'zenith bank', 100, 'pay', 0, '2024-11-09 17:00:02', ''),
(8, 'loans@gmail.com', 690000040, 'Access bank', 100, 'pay', 0, '2024-11-09 18:21:35', ''),
(9, 'loans@gmail.com', 690000040, 'Access bank', 100, 'pay', 0, '2024-11-09 18:31:20', ''),
(10, 'loans@gmail.com', 690000040, 'Access bank', 100, 'pay', 0, '2024-11-09 18:34:33', ''),
(11, 'loans@gmail.com', 690000040, 'Access bank', 100, 'pay', 0, '2024-11-09 19:14:38', ''),
(12, 'loans@gmail.com', 690000040, 'Access bank', 100, 'pay', 0, '2024-11-09 19:15:35', ''),
(13, 'loans@gmail.com', 690000040, 'Access bank', 100, 'pay', 0, '2024-11-09 19:19:04', ''),
(14, 'loans@gmail.com', 690000040, 'Access bank', 50, 'pay', 0, '2024-11-09 19:36:12', ''),
(15, 'loans@gmail.com', 690000040, 'Access bank', 50, 'pay', 0, '2024-11-09 21:26:14', ''),
(16, 'loans@gmail.com', 690000040, 'Access bank', 50, 'pay', 0, '2024-11-09 21:27:37', ''),
(17, 'loans@gmail.com', 690000040, 'Access bank', 100, 'pay', 0, '2024-11-09 21:28:09', ''),
(18, 'loans@gmail.com', 690000040, 'Access bank', 100, 'pay', 0, '2024-11-10 12:14:07', '8b2a4dce00ba6e4b7c72739eb94e9cb9'),
(19, 'loans@gmail.com', 690000040, 'Access bank', 100, 'pay', 0, '2024-11-11 01:38:00', 'd44c3c56bcc59cf397ce4cb3dffd221c');

-- --------------------------------------------------------

--
-- Table structure for table `borrower`
--

CREATE TABLE `borrower` (
  `borrower_id` int(11) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `contact_no` varchar(15) NOT NULL,
  `address` text NOT NULL,
  `email` varchar(30) NOT NULL,
  `tax_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `borrower`
--

INSERT INTO `borrower` (`borrower_id`, `firstname`, `middlename`, `lastname`, `contact_no`, `address`, `email`, `tax_id`) VALUES
(1, 'ADE', 'J', 'JAMES', '3456 657 7890', 'SSDFGG', 'ADD@ER.COM', '4455');

-- --------------------------------------------------------

--
-- Table structure for table `create_investment_plan`
--

CREATE TABLE `create_investment_plan` (
  `id` int(11) NOT NULL,
  `investment_plan` varchar(500) NOT NULL,
  `investment_amount` int(11) NOT NULL,
  `RIO` varchar(500) NOT NULL,
  `investment_name` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `create_investment_plan`
--

INSERT INTO `create_investment_plan` (`id`, `investment_plan`, `investment_amount`, `RIO`, `investment_name`) VALUES
(1, '3 months plan', 2000, '40%', 'housing'),
(2, '6 months plan', 5000, '20%', 'Agriculture');

-- --------------------------------------------------------

--
-- Table structure for table `credit_balance`
--

CREATE TABLE `credit_balance` (
  `id` int(11) NOT NULL,
  `user_account` varchar(500) NOT NULL,
  `amount_to_balance` int(15) NOT NULL,
  `added_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `credit_balance`
--

INSERT INTO `credit_balance` (`id`, `user_account`, `amount_to_balance`, `added_date`) VALUES
(1, 'loans@gmail.com', 1000, '0000-00-00 00:00:00'),
(2, 'loans@gmail.com', 1000, '0000-00-00 00:00:00'),
(3, 'loans@gmail.com', 1000, '0000-00-00 00:00:00'),
(4, 'loans@gmail.com', 1000, '0000-00-00 00:00:00'),
(5, 'loans@gmail.com', 1000, '0000-00-00 00:00:00'),
(6, 'loans@gmail.com', 1000, '0000-00-00 00:00:00'),
(7, 'loans@gmail.com', 1000, '0000-00-00 00:00:00'),
(8, 'loans@gmail.com', 1000, '0000-00-00 00:00:00'),
(9, 'loans@gmail.com', 1000, '2024-11-05 03:06:57'),
(10, 'loans@gmail.com', 1000, '2024-11-05 03:11:45'),
(11, 'loans@gmail.com', 1000, '2024-11-05 03:23:38'),
(12, 'loans@gmail.com', 1000, '2024-11-05 03:26:21'),
(13, 'loans@gmail.com', 1000, '2024-11-05 03:26:44'),
(14, 'loans@gmail.com', 1000, '2024-11-05 03:28:20'),
(15, 'loans@gmail.com', 1000, '2024-11-05 03:31:33');

-- --------------------------------------------------------

--
-- Table structure for table `investment`
--

CREATE TABLE `investment` (
  `id` int(11) NOT NULL,
  `account_user` varchar(500) NOT NULL,
  `investment_name` varchar(500) NOT NULL,
  `investment_plan` varchar(500) NOT NULL,
  `investment_duration` varchar(500) NOT NULL,
  `estimated_returns` int(11) NOT NULL,
  `payback_date` date DEFAULT NULL,
  `investment_status` varchar(500) NOT NULL,
  `investment_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `investment`
--

INSERT INTO `investment` (`id`, `account_user`, `investment_name`, `investment_plan`, `investment_duration`, `estimated_returns`, `payback_date`, `investment_status`, `investment_date`) VALUES
(1, 'loans@gmail.com', 'loans@gmail.com', '3 weeks plan', '23 days', 26000, '2024-10-22', 'Complete', '2024-11-07'),
(2, 'loans@gmail.com', 'loans@gmail.com', '3 weeks plan', '23 days', 2000, '2024-10-22', 'Active', '2024-11-07'),
(3, 'loans@gmail.com', 'loans@gmail.com', '3 weeks plan', '23 days', 2000, '2024-10-22', 'Active', '2024-11-07'),
(4, 'loans@gmail.com', 'loans@gmail.com', '3 weeks plan', '23 days', 2000, '2024-10-22', 'Active', '2024-11-07'),
(5, 'loans@gmail.com', 'loans@gmail.com', '3 weeks plan', '23 days', 2000, '2024-10-22', 'Active', '2024-11-07'),
(6, 'loans@gmail.com', 'Agriculture', '3 weeks plan', '23 days', 2000, '2024-10-22', 'Active', '2024-11-07'),
(7, 'loans@gmail.com', 'Agriculture', '3 weeks plan', '23 days', 2000, '2024-10-22', 'Active', '2024-11-09'),
(8, 'loans@gmail.com', 'Agriculture', '3 weeks plan', '23 days', 2000, '2024-10-22', 'Active', '2024-11-11'),
(9, 'loans@gmail.com', 'Agriculture', '3 weeks plan', '23 days', 2000, '2024-10-22', 'Active', '2024-11-11'),
(10, 'vicas@gmail.com', 'Agriculture', '3 weeks plan', '23 days', 2000, '2024-10-22', 'Active', '2024-11-11');

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

CREATE TABLE `loan` (
  `id` int(11) NOT NULL,
  `account_user` varchar(500) NOT NULL,
  `marital_status` varchar(150) NOT NULL,
  `loan_amount` int(11) NOT NULL,
  `education` varchar(500) NOT NULL,
  `occupation` varchar(500) NOT NULL,
  `state` varchar(300) NOT NULL,
  `home_address` text NOT NULL,
  `monthly_income` int(11) NOT NULL,
  `guarantor_name` varchar(500) NOT NULL,
  `guarantor_phone` varchar(500) NOT NULL,
  `guarantor_state` varchar(300) NOT NULL,
  `guarantor_home_address` text NOT NULL,
  `date_applied` date DEFAULT NULL,
  `loan_time` time NOT NULL,
  `loan_status` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `loan`
--

INSERT INTO `loan` (`id`, `account_user`, `marital_status`, `loan_amount`, `education`, `occupation`, `state`, `home_address`, `monthly_income`, `guarantor_name`, `guarantor_phone`, `guarantor_state`, `guarantor_home_address`, `date_applied`, `loan_time`, `loan_status`) VALUES
(1, 'loans@gmail.com', 'single', 4000, 'O level', 'Student', 'Enugu', 'Udensi N0 9', 20000, 'Victor', '0903034033', 'Ebonyi', 'Udensi No 7', '2024-11-07', '04:28:05', 0),
(2, 'loans@gmail.com', 'single', 4000, 'O level', 'Student', 'Enugu', 'Udensi N0 9', 20000, 'Victor', '0903034033', 'Ebonyi', 'Udensi No 7', '2024-11-08', '01:46:28', 0),
(3, 'loans@gmail.com', 'single', 4000, 'O level', 'Student', 'Enugu', 'Udensi N0 9', 20000, 'Victor', '0903034033', 'Ebonyi', 'Udensi No 7', '2024-11-09', '21:30:45', 0),
(4, 'loans@gmail.com', 'single', 4000, 'O level', 'Student', 'Enugu', 'Udensi N0 9', 20000, 'Victor', '0903034033', 'Ebonyi', 'Udensi No 7', '2024-11-10', '12:27:11', 0),
(5, 'loans@gmail.com', 'single', 4000, 'O level', 'Student', 'Enugu', 'Udensi N0 9', 20000, 'Victor', '0903034033', 'Ebonyi', 'Udensi No 7', '2024-11-11', '01:45:42', 0),
(6, 'loans@gmail.com', 'single', 4000, 'O level', 'Student', 'Enugu', 'Udensi N0 9', 20000, 'Victor', '0903034033', 'Ebonyi', 'Udensi No 7', '2024-11-13', '00:35:19', 0),
(7, 'loans@gmail.com', 'single', 4000, 'O level', 'Student', 'Enugu', 'Udensi N0 9', 20000, 'Victor', '0903034033', 'Ebonyi', 'Udensi No 7', '2024-11-13', '00:36:52', 0);

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `id` int(11) NOT NULL,
  `account_user` varchar(500) NOT NULL,
  `notified_msg` text NOT NULL,
  `notification_type` varchar(500) NOT NULL,
  `notified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `repay_loan`
--

CREATE TABLE `repay_loan` (
  `id` int(11) NOT NULL,
  `user_account` varchar(500) NOT NULL,
  `amount_paid` int(11) NOT NULL,
  `paid_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `repay_loan`
--

INSERT INTO `repay_loan` (`id`, `user_account`, `amount_paid`, `paid_date`) VALUES
(1, 'loans@gmail.com', 100, '2024-11-07 02:04:33'),
(2, 'loans@gmail.com', 100, '2024-11-07 02:05:11'),
(3, 'loans@gmail.com', 100, '2024-11-10 00:43:17'),
(4, 'loans@gmail.com', 100, '2024-11-10 12:15:38'),
(5, 'loans@gmail.com', 100, '2024-11-10 12:22:10'),
(6, 'loans@gmail.com', 100, '2024-11-11 01:40:59'),
(7, 'loans@gmail.com', 100, '2024-11-13 00:30:12');

-- --------------------------------------------------------

--
-- Table structure for table `telecommunication`
--

CREATE TABLE `telecommunication` (
  `id` int(11) NOT NULL,
  `user_account` varchar(500) NOT NULL,
  `network` varchar(500) NOT NULL,
  `amount` int(11) NOT NULL,
  `purchase_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `telecommunication`
--

INSERT INTO `telecommunication` (`id`, `user_account`, `network`, `amount`, `purchase_date`) VALUES
(1, 'loans@gmail.com', '07030865642', 100, '2024-11-07 02:45:03'),
(2, 'loans@gmail.com', '07030865642', 100, '2024-11-07 02:45:03'),
(3, 'loans@gmail.com', '07030865642', 100, '2024-11-07 02:45:54'),
(4, 'loans@gmail.com', '07030865642', 100, '2024-11-07 02:45:54'),
(5, 'loans@gmail.com', '07030865642', 100, '2024-11-07 02:50:37'),
(6, 'loans@gmail.com', '07030865642', 100, '2024-11-07 02:52:10'),
(7, 'loans@gmail.com', '07030865642', 100, '2024-11-10 02:53:35'),
(8, 'loans@gmail.com', '07030865642', 100, '2024-11-10 03:12:50'),
(9, 'loans@gmail.com', '07030865642', 100, '2024-11-10 03:13:49'),
(10, 'loans@gmail.com', '07030865642', 100, '2024-11-10 04:19:02'),
(11, 'loans@gmail.com', '07030865642', 100, '2024-11-10 12:24:03'),
(12, 'loans@gmail.com', '07030865642', 100, '2024-11-11 01:42:48');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `transaction_type` varchar(500) NOT NULL,
  `transaction_amount` int(11) NOT NULL,
  `transaction_user` varchar(500) NOT NULL,
  `transaction_status` varchar(500) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `ref` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `transaction_type`, `transaction_amount`, `transaction_user`, `transaction_status`, `transaction_date`, `ref`) VALUES
(1, 'Deposit', 1000, 'loans@gmail.com', 'Successful', '0000-00-00 00:00:00', ''),
(2, 'Deposit', 1000, 'loans@gmail.com', 'Successful', '0000-00-00 00:00:00', ''),
(3, 'Deposit', 1000, 'loans@gmail.com', 'Successful', '0000-00-00 00:00:00', ''),
(4, 'Deposit', 1000, 'loans@gmail.com', 'Successful', '2024-11-05 03:06:57', ''),
(5, 'Deposit', 1000, 'loans@gmail.com', 'Successful', '2024-11-05 03:11:45', ''),
(6, 'Deposit', 1000, 'loans@gmail.com', 'Successful', '2024-11-05 03:23:38', ''),
(7, 'Deposit', 1000, 'loans@gmail.com', 'Successful', '2024-11-05 03:26:21', ''),
(8, 'Deposit', 1000, 'loans@gmail.com', 'Successful', '2024-11-05 03:26:44', ''),
(9, 'Deposit', 1000, 'loans@gmail.com', 'Successful', '2024-11-05 03:28:20', ''),
(10, 'Deposit', 1000, 'loans@gmail.com', 'Successful', '2024-11-05 03:31:33', ''),
(11, 'Withdrawal', 11, 'loans@gmail.com', 'Processing', '2024-11-06 01:57:05', ''),
(12, 'Withdrawal', 11, 'loans@gmail.com', 'Processing', '2024-11-06 01:58:06', ''),
(13, 'Withdrawal', 11, 'loans@gmail.com', 'successful', '2024-11-06 01:59:36', ''),
(14, 'Withdrawal', 100, 'loans@gmail.com', 'successful', '2024-11-06 02:18:29', ''),
(15, 'Withdrawal', 100, 'loans@gmail.com', 'successful', '2024-11-06 02:19:59', ''),
(16, 'Withdrawal', 100, 'loans@gmail.com', 'successful', '2024-11-06 02:25:36', ''),
(17, 'Withdrawal', 100, 'loans@gmail.com', 'successful', '2024-11-06 02:30:48', ''),
(18, 'Withdrawal', 100, 'loans@gmail.com', 'successful', '2024-11-06 02:33:10', ''),
(19, 'Repaid loan', 100, 'loans@gmail.com', 'completed', '2024-11-07 02:04:33', ''),
(20, 'Repaid loan', 100, 'loans@gmail.com', 'completed', '2024-11-07 02:05:11', ''),
(21, 'Withdrawal', 100, 'loans@gmail.com', 'successful', '2024-11-09 17:00:02', ''),
(22, 'Withdrawal', 100, 'loans@gmail.com', 'successful', '2024-11-09 18:21:35', ''),
(23, 'Withdrawal', 100, 'loans@gmail.com', 'successful', '2024-11-09 18:31:20', ''),
(24, 'Withdrawal', 100, 'loans@gmail.com', 'successful', '2024-11-09 18:34:33', ''),
(25, 'Withdrawal', 100, 'loans@gmail.com', 'successful', '2024-11-09 19:14:38', ''),
(26, 'Withdrawal', 100, 'loans@gmail.com', 'successful', '2024-11-09 19:15:35', ''),
(27, 'Withdrawal', 100, 'loans@gmail.com', 'successful', '2024-11-09 19:19:04', ''),
(28, 'Withdrawal', 50, 'loans@gmail.com', 'successful', '2024-11-09 19:36:12', ''),
(29, 'Withdrawal', 50, 'loans@gmail.com', 'successful', '2024-11-09 21:26:14', ''),
(30, 'Withdrawal', 50, 'loans@gmail.com', 'successful', '2024-11-09 21:27:37', ''),
(31, 'Withdrawal', 100, 'loans@gmail.com', 'successful', '2024-11-09 21:28:09', ''),
(32, 'Repaid loan', 100, 'loans@gmail.com', 'completed', '2024-11-10 00:43:17', 'be3ce7cfa73b67584908800df77f5d22'),
(33, 'Withdrawal', 100, 'loans@gmail.com', 'successful', '2024-11-10 12:14:07', '8b2a4dce00ba6e4b7c72739eb94e9cb9'),
(34, 'Repaid loan', 100, 'loans@gmail.com', 'completed', '2024-11-10 12:15:38', '36232d149a28ee045ed13816445db586'),
(35, 'Repaid loan', 100, 'loans@gmail.com', 'completed', '2024-11-10 12:22:10', 'f6bb18ce40ee8b456a544ffdae0ca1c8'),
(36, 'Withdrawal', 100, 'loans@gmail.com', 'successful', '2024-11-11 01:38:00', 'd44c3c56bcc59cf397ce4cb3dffd221c'),
(37, 'Repaid loan', 100, 'loans@gmail.com', 'completed', '2024-11-11 01:40:59', '9635f0facb37a1ebf693853489a7774c'),
(38, 'Repaid loan', 100, 'loans@gmail.com', 'completed', '2024-11-13 00:30:12', '28a09823bd06b4ef0d1ec8b0a61d9808');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(500) NOT NULL,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `initiated_reference` varchar(500) NOT NULL,
  `phone` varchar(500) NOT NULL,
  `barter_id` varchar(500) NOT NULL,
  `acct_reference` varchar(500) NOT NULL,
  `identity_number` int(15) NOT NULL,
  `account_status` varchar(500) NOT NULL,
  `authentication_code` varchar(500) NOT NULL,
  `authenticate` tinyint(1) DEFAULT 0,
  `verified` int(11) NOT NULL,
  `verification_code` int(11) DEFAULT NULL,
  `user_image` text NOT NULL,
  `user_inflow_in_30day` int(11) NOT NULL,
  `user_total_loan_amount` int(11) NOT NULL,
  `user_no_of_application` int(11) NOT NULL,
  `user_bank` varchar(500) NOT NULL,
  `user_account_number` int(11) NOT NULL,
  `user_outstanding_loan` int(11) NOT NULL,
  `investment_balance` int(11) NOT NULL,
  `reset_password` int(11) NOT NULL,
  `reset_pin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `firstname`, `lastname`, `initiated_reference`, `phone`, `barter_id`, `acct_reference`, `identity_number`, `account_status`, `authentication_code`, `authenticate`, `verified`, `verification_code`, `user_image`, `user_inflow_in_30day`, `user_total_loan_amount`, `user_no_of_application`, `user_bank`, `user_account_number`, `user_outstanding_loan`, `investment_balance`, `reset_password`, `reset_pin`) VALUES
(2, 'admin@mail.com', '@!admin0123', 'Administrator', 'creditpal', '', '', '', '', 0, '', '0', 0, 0, NULL, '', 0, 0, 0, '', 0, 0, 0, 0, 0),
(15, 'loan@gmail.com', '$2y$10$LDpJI65NeUly1mWvAi5cbOGZ5gZ7DUeadr0T9Uy0sr8wQ2hBFGCuq', '', '', '', '', '', '', 1111111, 'enabled', '$2y$10$skfUlFZ7Z3xCxZDeJXI7AeYNgt6sfo/oy2uJxnEr2l/fUY.He0fSu', 1, 1, 0, '', 0, 0, 0, '', 0, 0, 0, 0, 0),
(16, 'loans@gmail.com', '$2y$10$axxSre0CqUG8fxJhtEolgOa/5VSNVMZnXbz/TBNBS2ErivhUBuNyG', '', '', '', '', '', 'PSA2EDCFEE55D3134972', 1111111, 'enabled', '$2y$10$i6N1ZyscvByJP1kfbrFAAO1Rq99qwhXA1bDqyj7Bq.uiyplbNvoB2', 1, 1, 0, '', 0, 0, 0, '', 0, 300, 42000, 0, 0),
(17, 'e@gmail.com', '$2y$10$EikRWj/C/QgI8O3aa3UgOORehWHO.UNBy6CDtXTL9BYfqoxyyE6F6', 'Muolokwu', 'Obi', '', '1222', '', '', 2147483647, 'enabled', '', 0, 0, 7968, '', 0, 0, 0, 'Mock Bank', 67100155, 0, 0, 0, 0),
(18, 'A@gmail.com', '$2y$10$aGrUF/y/UDIOv55LjRjmV.wL.zLU.mWX8PsTH6M/jrUap.BVIDaKi', 'Muolokwu', 'Obi', '', '', '', '', 2147483647, 'enabled', '', 0, 0, 1565, '', 0, 0, 0, 'Mock Bank', 67100155, 0, 0, 0, 0),
(19, 'q@gmail.com', '$2y$10$zfJwqcwM10nGtTs3J0MxpuHuCly71noK1JoUhMhhmnZf0yRWrqccC', 'Muolokwu', 'Obi', '', '', '', '', 2147483647, 'enabled', '', 0, 0, 6953, '', 0, 0, 0, 'Mock Bank', 67100155, 0, 0, 0, 0),
(20, 'qa@gmail.com', '$2y$10$gvN8ZsEOT8LoUYrqGKIYy.fgV6J.UVL5EAV24gGjeG2XAT/mlKnvm', 'Muolokwu', 'Obi', '', '', '', '', 2147483647, 'enabled', '', 0, 0, 6568, '', 0, 0, 0, 'Mock Bank', 67100155, 0, 0, 0, 0),
(21, 'qas@gmail.com', '$2y$10$cKfr3.sHGW0N7CFu624kgexBgW5YQJom8BdShYNpnFBqAqsqM7g1e', 'Muolokwu', 'Obi', '', '', '', '', 2147483647, 'enabled', '', 0, 0, 1482, '', 0, 0, 0, 'Mock Bank', 67100155, 0, 0, 0, 0),
(22, 'qass@gmail.com', '$2y$10$fdlWZll/8dPpDQNGrtjmIeVMO5GVxfzuqH53wkFCDQKd3dE9IygT2', 'Muolokwu', 'Obi', '', '', '', '', 2147483647, 'enabled', '', 0, 0, 1126, '', 0, 0, 0, 'Mock Bank', 67100155, 0, 0, 0, 0),
(23, 'qasys@gmail.com', '$2y$10$KFghOj.qTaxTLtwBa0LbNuBt99PLGq78QpZ7lbMSBwgDUflQH5jKW', 'Muolokwu', 'Obi', '', '', '', '', 2147483647, 'enabled', '', 0, 0, 7832, '', 0, 0, 0, 'Mock Bank', 67100155, 0, 0, 0, 0),
(24, 'qasyrs@gmail.com', '$2y$10$eV8tucnCGChrT5svkpqhXeVQOlVpWunAiSo52pV5k369/yWL3H2BS', 'Muolokwu', 'Obi', '', '', '', '', 2147483647, 'enabled', '', 0, 0, 3290, '', 0, 0, 0, 'Mock Bank', 67100155, 0, 0, 0, 0),
(25, 'qasyrus@gmail.com', '$2y$10$HNMvPIylb6FIMl3TYhUxVuybZ1cPCqXSbEP8Twjx4xqT4/wF08c7O', 'Muolokwu', 'Obi', '', '', '', '', 2147483647, 'enabled', '', 0, 0, 8295, '', 0, 0, 0, 'Mock Bank', 67100155, 0, 0, 0, 0),
(26, 'qasyerus@gmail.com', '$2y$10$wffxZNjfujwqoTB932NQzOZRWXci4m8QIpXV6TdTd1/oJjqwY0BlW', 'Muolokwu', 'Obi', '', '', '', '', 2147483647, 'enabled', '', 0, 0, 1311, '', 0, 0, 0, 'Mock Bank', 67100155, 0, 0, 0, 0),
(27, 'lwasiw@gmail.com', '$2y$10$ONf9fTyyx70he9h7lef4Y.NxMJ.LUEoAzflRTZQd.Njz4v7EfG.OO', 'Nibby', 'Certifier', 'FLW0A0AABA4F2BE9EBEBA714E', '07089374787', '234000002560560', 'PSA97B52F776A2952906', 2147483647, 'enabled', '', 0, 0, 7862, 'https://www.domain.com/default.jpg', 0, 0, 0, 'Sterling Bank', 2147483647, 0, 0, 0, 0),
(28, 'lwasiwq@gmail.com', '$2y$10$NpADY/BzskFAYWqMXW7tSuqu2puZS2DGxQ815vEmYy9972M9NGIHe', 'Nibby', 'Certifier', 'FLW939C89A872B8A9D7B5F86A', '07089374787', '234000002560561', 'PSA2EDCFEE55D3134972', 2147483647, 'enabled', '', 0, 0, 5779, 'https://www.domain.com/default.jpg', 0, 0, 0, 'Sterling Bank', 2147483647, 0, 0, 0, 0),
(29, 'lwasiqwq@gmail.com', '$2y$10$vMwkL8ReFS8bN/OXV9cpReWORM2j2S0/vVrhVDk/rD9sDnHcBK0j2', 'Nibby', 'Certifier', 'FLW410A7D422E9497F8555204', '07089374787', '234000002560562', 'PSA4DEFB7B1B53305178', 2147483647, 'enabled', '', 0, 0, 8091, 'https://www.domain.com/default.jpg', 0, 0, 0, 'Sterling Bank', 2147483647, 0, 0, 0, 0),
(30, 'egokense@gmail.com', '$2y$10$uPfX3s5YoqMRIUsVxxrrG.gvX79wzpsPAMQyaZ3rK2woZJAu2Iohm', 'Nibby', 'Certifier', 'FLW47F37B4D513F6B0C6632C9', '07089374787', '234000002560828', 'PSAFE50F2D0F12319968', 2147483647, 'enabled', '', 0, 0, 8179, 'https://www.domain.com/app/default.jpg', 0, 0, 0, 'Sterling Bank', 2147483647, 0, 0, 0, 0),
(31, 'egoeksq@gmail.com', '$2y$10$6GSRxecd.MXZn7EpE0JjwuMQp/GSagMfZ5We11GkR..jSNE4M5aKm', 'Nibby', 'Certifier', 'FLWDA4CC93A8BFBFE4B56F485', '07089374787', '234000002560833', 'PSAC203CDCE9F4767266', 2147483647, 'enabled', '', 0, 0, 1004, 'https://www.domain.com/app/default.jpg', 0, 0, 0, 'Sterling Bank', 2147483647, 0, 0, 0, 0),
(32, 'egwoeksq@gmail.com', '$2y$10$nlYiHoK8QWDv1MCRMb/cNOTmdtkta8AKWhuBjc/8HxGgk1EuMU0JK', 'Nibby', 'Certifier', 'FLWF3AD2176BAD7BC76D52ED3', '07089374787', '234000002560834', 'PSAA87C92D3DC4958443', 2147483647, 'enabled', '', 0, 0, 8662, 'https://www.domain.com/app/default.jpg', 0, 0, 0, 'Sterling Bank', 2147483647, 0, 0, 0, 0),
(33, ':username', ':password', ':firstname', ':lastname', ':initiated_reference', ':phone', ':barter_id', ':acct_reference', 0, ':account_status', '', 0, 0, 0, ':user_image', 0, 0, 0, ':user_bank', 0, 0, 0, 0, 0),
(34, 'vicas@gmail.com', '$2y$10$bEYydw2cymN00kZTFjAKBu8EcdiMIZVFHFRDPGBmNt98Zk.ee6mne', 'Nibby', 'Certifier', 'FLW74245FED2828BF82BA2149', '07089374787', '234000002561066', 'PSABCECFF03048610124', 2147483647, 'enabled', '$2y$10$7.iSkM0RLcJhbhD0iSKXXe8w4dQqmGFd6GRYhmIyL/H95uekxOMQS', 1, 1, 0, 'https://www.domain.com/app/default.jpg', 0, 0, 0, 'Sterling Bank', 2147483647, 0, 2000, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `bank_transfer`
--
ALTER TABLE `bank_transfer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `borrower`
--
ALTER TABLE `borrower`
  ADD PRIMARY KEY (`borrower_id`);

--
-- Indexes for table `create_investment_plan`
--
ALTER TABLE `create_investment_plan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `credit_balance`
--
ALTER TABLE `credit_balance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `investment`
--
ALTER TABLE `investment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `loan`
--
ALTER TABLE `loan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `repay_loan`
--
ALTER TABLE `repay_loan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `telecommunication`
--
ALTER TABLE `telecommunication`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `bank_transfer`
--
ALTER TABLE `bank_transfer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `borrower`
--
ALTER TABLE `borrower`
  MODIFY `borrower_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `create_investment_plan`
--
ALTER TABLE `create_investment_plan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `credit_balance`
--
ALTER TABLE `credit_balance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `investment`
--
ALTER TABLE `investment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `loan`
--
ALTER TABLE `loan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `repay_loan`
--
ALTER TABLE `repay_loan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `telecommunication`
--
ALTER TABLE `telecommunication`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
