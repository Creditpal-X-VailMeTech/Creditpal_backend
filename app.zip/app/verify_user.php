<?php

header("Content-type: application/json;meta-charset=UTF-8");

require_once "app_classes/Config_db.php";
require_once "app_classes/config_session.php";
require_once "app_classes/Class_app_verify_email.php";


if ($_SERVER['REQUEST_METHOD'] === "POST") {

	//getting the required details with php inputs
	$detail=json_decode(file_get_contents("php://input"),true);

	$uid=$detail['username'];
	$pin=$detail['verification_code'];

	//calling the classname to run the code

	$verify_me=new Verify_email($uid,$pin);


	//IF empty
	if ($verify_me->error_handle_verification()) {
		
		$error=[
			"error"=>"Empty Field",
			"user" => $uid
		];
		
		echo json_encode($error,JSON_NUMERIC_CHECK);
		die();
	}


	//invalid user
	if ($verify_me->validate()) {
		
		$error=[
			"error"=>"Invalid user",
			"user" => $uid
		];
		
		echo json_encode($error,JSON_NUMERIC_CHECK);
		die();
	}


	//incorrect pin
	if (!$verify_me->validates_pin()) {
	

		$error=[
			"error"=>"Incorrect Pin",
			"user" => $uid
		];
		
		echo json_encode($error,JSON_NUMERIC_CHECK);
		die();

	}


	//successful
	if ($verify_me->validates_pin()) {
			

	}



}else{
	$error=["error"=>"Error Invalid access"];

		echo json_encode($error,JSON_NUMERIC_CHECK);

		die();
}