<?php


header("Content-type: application/json;meta-charset=UTF-8");

require_once "app_classes/Config_db.php";
require_once "app_classes/config_session.php";
require_once "app_classes/Class_app_investment.php";

if ($_SERVER['REQUEST_METHOD'] === "POST") {
	
	


	//calling the investment class
	$verify=new Investment_plan();

	//SECTION FOR AUTHORIZATION TO ACCESS THE DATA FROM THE DATABASE

	if($verify->validate()){

		$error=["error"=>"Invalid user"];

		return json_encode($error);

		die();

	}


	try{

		if (!$verify->validate()) {
		
		$verify->view_investment_plan();

		die();
	}

	}catch(PDOException $e){

		die("Connection:". $e->getMessage());

	}

	



}else{

	$message=["error"=>'Invalid access'];

	return json_encode($message);
	die();

}