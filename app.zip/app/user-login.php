<?php

header("Content-type: application/json;meta-charset=UTF-8");

require_once "load_env.php";

require_once "app_classes/Config_db.php";
require_once "app_classes/config_session.php";
require_once "app_classes/Class_app_login.php";

include_once 'vendor/autoload.php';

use Firebase\JWT\JWT;

if($_SERVER['REQUEST_METHOD'] === "POST"){


	$details=json_decode(file_get_contents("php://input"),true);

	$uid=$details['username'];
	$pwd=$details['password'];


	$validation_file=new User_login_validation($uid,$pwd);


	//Checking if the fields are empty

	if ($validation_file->login_error_handler()) {
		
		$error=["error"=>"Empty Field !"];

		echo json_encode($error,JSON_NUMERIC_CHECK);

		die();
	}


	//Checking if the login details are correct

	if (!$validation_file->logged_in()) {
		
		$error=["error"=>"Invalid username and password"];

		echo json_encode($error,JSON_NUMERIC_CHECK);

		die();
	}



	//IF all the details are correct, then log in the user

	if (!$validation_file->login_error_handler() && $validation_file->logged_in()) {
		
	$data=new Load_me;

		$key = "".$data->display_me()['token_me']."";
		$payload = [
    			'iss' => 'http://example.org',
   				 'aud' => 'http://example.com',
   				 'iat' => time(),
   				 'nbf' => strtotime("+1 hour"),
				 'username' => $validation_file->logged_in(),

				 ];


			$jwt = JWT::encode($payload, $key, 'HS256');

			$result=[
				 
				 'message' => 'Login successful',
				 'token' =>$jwt
			];	 


		echo json_encode($result,JSON_NUMERIC_CHECK);

		die();


	}



}else{

	$error=["error"=>"Error Invalid access"];

		echo json_encode($error,JSON_NUMERIC_CHECK);

		die();
}
