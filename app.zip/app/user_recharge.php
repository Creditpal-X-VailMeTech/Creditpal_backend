<?php

header("Content-type: application/json;meta-charset=UTF-8");

require_once "app_classes/Config_db.php";
require_once "app_classes/config_session.php";
require_once "app_classes/Class_app_airtime_data.php";


if ($_SERVER['REQUEST_METHOD'] === "POST") {

	//Get the details
	$details=json_decode(file_get_contents("php://input"),true);

	$phone=$details['phone_number'];
	$amount=$details['amount'];
	$bank="Access Bank";
	$acct_number="0690000040";
	$note="Repay loan";
	$ref=md5(time());

	if ($amount === "") {
		$amount=0;
	}


	//Calling the class name for purchasing the airtime
	$tele=new Buy_data_and_airtime($phone,$amount,$bank,$acct_number,$note,$ref);


	//checking if any of the parameters are empty
	if (!$tele->token_verification()) {
		
		$error=["error"=>"Invalid or expired token"];

		echo json_encode($error);
		die();

	}



	//checking if any of the parameters are empty
	if ($tele->error_handle_airtime()) {
		
		$error=["error"=>"Field is empty"];

		echo json_encode($error);
		die();

	}



	//checking if it is a valid user
	if ($tele->check_user()) {
		
		$error=["error"=>"Invalid user"];

		echo json_encode($error);
		die();
	}



	//If all the validation is valid then purchase the airtime for the user
	try{

		if ($tele->process_airtime_for_user() && !$tele->check_user() && $tele->token_verification() && !$tele->error_handle_airtime()) {
				$message=["message"=>"Purchase successful"];

			echo json_encode($message);
			die();
		}elseif (!$tele->process_airtime_for_user()) {
					
			$message=["message"=>"You have insufficient fund to perform this operation"];

			echo json_encode($message);
			die();
		}

	}catch(PDOException $e){

		die("Connection: " . $e->getMessage());
	}
	
	
}else{
	$message=["error"=>"Invalid access to the page"];

	echo json_encode($message);
	die();
}
