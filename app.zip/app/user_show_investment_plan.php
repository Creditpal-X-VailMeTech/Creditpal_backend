<?php


header("Content-type: application/json;meta-charset=UTF-8");

require_once "app_classes/Config_db.php";
require_once "app_classes/config_session.php";
require_once "app_classes/Class_app_display_investment.php";


if ($_SERVER['REQUEST_METHOD'] === "GET") {
	


//Gettin the dispaly class
$display=new Show_investment_plan;

if ($display->empty_display()) {
	
	$info=["message"=>"There is no invesment plan at the moment"];

	echo json_encode($info);
	die();


}

if (!$display->token_verification()) {
	$info=["message"=>"Expired or invalid token"];

	echo json_encode($info);
	die();

}



if($display->display() && !$display->empty_display() && $display->token_verification()){

	die();
}


}else{
		$error=["error"=>"Invalid Access"];

	echo json_encode($error);
	die();
}
