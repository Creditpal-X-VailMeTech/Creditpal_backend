<?php

header("Content-type: application/json;meta-charset=UTF-8");

require_once "app_classes/Config_db.php";
require_once "app_classes/config_session.php";
require_once "app_classes/Class_request_reset_password.php";


if ($_SERVER['REQUEST_METHOD'] === "POST") {

	//getting the required details with php inputs
	$detail=json_decode(file_get_contents("php://input"),true);

	$uid=$detail['username'];

	//calling the classname to run the code

	$verify_me=new Request_reset_password($uid);


	//IF empty
	if ($verify_me->error_handle_request()) {
		
		$error=[
			"error"=>"Empty Field",
			"user" => $uid
		];
		
		echo json_encode($error,JSON_NUMERIC_CHECK);
		die();
	}


	//invalid user
	if ($verify_me->validate_user()) {
		
		$error=[
			"error"=>"Invalid user",
			"user" => $uid
		];
		
		echo json_encode($error,JSON_NUMERIC_CHECK);
		die();
	}




	//successful
	if ($verify_me->email_validated_user()) {
			

				$message=[
			"message"=>"Email sent to user",
			"user" => $uid
		];
		
		echo json_encode($message,JSON_NUMERIC_CHECK);
		die();

	}



}else{
	$error=["error"=>"Error Invalid access"];

		echo json_encode($error,JSON_NUMERIC_CHECK);

		die();
}