

<?php
/*$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.flutterwave.com/v3/virtual-account-numbers',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS =>'{
   "email": "obimuolokwu@example.com",
    "is_permanent": true,
    "bvn": "2222122280",
    "phonenumber": "07030865642",
    "firstname": "Muolokwu",
    "lastname": " Obi",
    "narration": "Muolokwu Obi"

}',
  CURLOPT_HTTPHEADER => array(
	'Content-Type: application/json',

   'Authorization: Bearer FLWSECK_TEST-d0e85c930ac04fa693927227b3e3b2b2-X'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;









$number=md5(time());


$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.flutterwave.com/v3/transfers",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS =>'{
   "account_bank": "Access Bank",
    "account_number": "0690000031",
    "amount": 1000,
    "narration": "Akhlm Pstmn Trnsfr xx007",
    "currency": "NGN",
    "reference": "'.$number.'",
    "debit_currency": "NGN"

}',
  CURLOPT_HTTPHEADER => array(
  	    "Content-Type: application/json",
    "Authorization: Bearer FLWSECK_TEST-d0e85c930ac04fa693927227b3e3b2b2-X"
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;










$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.flutterwave.com/v3/payout-subaccounts/PSAFF2118D1A33844332/balances?currency=NGN",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS =>'{
   "account_bank": "Access Bank",
    "account_number": "0690000031",
    "amount": 1000,
    "narration": "Akhlm Pstmn Trnsfr xx007",
    "currency": "NGN",
    "reference": "'.$number.'",
    "debit_currency": "NGN"

}',
  CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        'Accept: application/json',
    "Authorization: Bearer FLWSECK_TEST-d0e85c930ac04fa693927227b3e3b2b2-X"
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;







//bvn verification


$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.flutterwave.com/v3/bvn/verifications",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS =>'{

    "bvn": "22222222280",
    "firstname": "Nibby",
    "lastname": "Certifier"

}',
  CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        'Accept: application/json',
    "Authorization: Bearer FLWSECK_TEST-d0e85c930ac04fa693927227b3e3b2b2-X"
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;





$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.flutterwave.com/v3/bvn/verifications/FLW9948B14BC645EAA18E6DB2",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        'Accept: application/json',
    "Authorization: Bearer FLWSECK_TEST-d0e85c930ac04fa693927227b3e3b2b2-X"
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;



$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.flutterwave.com/v3/payout-subaccounts",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS =>'{

     "account_name": "MUOLOKWU OBI",
  "email": "developer@flutterwavego.com",
  "mobilenumber": "070308767363",
  "country": "NG"

}',
  CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        'Accept: application/json',
    "Authorization: Bearer FLWSECK_TEST-d0e85c930ac04fa693927227b3e3b2b2-X"
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;




//get account

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.flutterwave.com/v3/payout-subaccounts/PSA54BE9963F99930550",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
   CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        'Accept: application/json',
    "Authorization: Bearer FLWSECK_TEST-d0e85c930ac04fa693927227b3e3b2b2-X"
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;



//get transaction details

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.flutterwave.com/v3/payout-subaccounts/PSA54BE9963F99930550/transactions",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
   CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        'Accept: application/json',
    "Authorization: Bearer FLWSECK_TEST-d0e85c930ac04fa693927227b3e3b2b2-X"
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;


//Available balance

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.flutterwave.com/v3/payout-subaccounts/PSA54BE9963F99930550/balances",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
   CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        'Accept: application/json',
    "Authorization: Bearer FLWSECK_TEST-d0e85c930ac04fa693927227b3e3b2b2-X"
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;






/*Available balance

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.flutterwave.com/v3/payout-subaccounts/PSA54BE9963F99930550/static-account",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
   CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        'Accept: application/json',
    "Authorization: Bearer FLWSECK_TEST-d0e85c930ac04fa693927227b3e3b2b2-X"
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;


$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.flutterwave.com/v3/payout-subaccounts",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS =>'{

     "account_name": "MUOLOKWU OBI",
  "email": "developr@flutterwavego.com",
  "mobilenumber": "070308767363",
  "country": "NG"

}',
  CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        'Accept: application/json',
    "Authorization: Bearer FLWSECK_TEST-d0e85c930ac04fa693927227b3e3b2b2-X"
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;






//getting the static account


$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.flutterwave.com/v3/payout-subaccounts/PSA7D0F6CD25D8062853/static-account",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  
  CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        'Accept: application/json',
    "Authorization: Bearer FLWSECK_TEST-d0e85c930ac04fa693927227b3e3b2b2-X"
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;



//getting balance



$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.flutterwave.com/v3/payout-subaccounts/PSA7D0F6CD25D8062853/balances",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
 
  CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        'Accept: application/json',
    "Authorization: Bearer FLWSECK_TEST-d0e85c930ac04fa693927227b3e3b2b2-X"
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;




//Getting transactions



$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.flutterwave.com/v3/payout-subaccounts/PSA7D0F6CD25D8062853/transactions?from=2024-11-09&to=2024-11-09",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
 
  CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        'Accept: application/json',
    "Authorization: Bearer FLWSECK_TEST-d0e85c930ac04fa693927227b3e3b2b2-X"
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;




*/

//funding account test



$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.flutterwave.com//v3/payout-subaccounts/PSA14A63E08EC9166335/fund-account",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS =>'{

     "currency": "NGN",
    "amount": "500"

}',
  CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        'Accept: application/json',
    "Authorization: Bearer FLWSECK_TEST-d0e85c930ac04fa693927227b3e3b2b2-X"
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;






/*
//withdrawing account test

$reference_payment=md5(time());


$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.flutterwave.com/v3/transfers",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS =>'{

    "account_bank": "Sterling Bank",
  "account_number": "6222187003",
  "amount": "100",
  "narration": "k",
  "currency": "NGN",
  "reference": "'.$reference_payment.'",
  "debit_currency": "NGN",
 "debit_subaccount": "PSA7D0F6CD25D8062853"

}',
  CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        'Accept: application/json',
    "Authorization: Bearer FLWSECK_TEST-d0e85c930ac04fa693927227b3e3b2b2-X"
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;




//fetch bills for airtime

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.flutterwave.com/v3/top-bill-categories",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  
  CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        'Accept: application/json',
    "Authorization: Bearer FLWSECK_TEST-d0e85c930ac04fa693927227b3e3b2b2-X"
  ),
));

$response = json_decode(curl_exec($curl),true);

curl_close($curl);
print_r($response['data'][0]);



//get network


$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.flutterwave.com/v3/bills/".$response['data'][0]['name']."/billers?country=NG",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  
  CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        'Accept: application/json',
    "Authorization: Bearer FLWSECK_TEST-d0e85c930ac04fa693927227b3e3b2b2-X"
  ),
));

$response = json_decode(curl_exec($curl),true);

curl_close($curl);
print_r($response);





//get bill code


$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.flutterwave.com/v3/billers/".$response['data'][0]['biller_code']."/items",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  
  CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        'Accept: application/json',
    "Authorization: Bearer FLWSECK_TEST-d0e85c930ac04fa693927227b3e3b2b2-X"
  ),
));

$response = json_decode(curl_exec($curl),true);

curl_close($curl);
print_r($response);





//validate user


$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.flutterwave.com/v3/bill-items/".$response['data'][0]['item_code']."/validate?code=".$response['data'][0]['biller_code']."&customer=07030865642'",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  
  CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        'Accept: application/json',
    "Authorization: Bearer FLWSECK_TEST-d0e85c930ac04fa693927227b3e3b2b2-X"
  ),
));

$response = json_decode(curl_exec($curl),true);

curl_close($curl);
print_r($response);






//pay bill



$reference_payment=md5(time());


$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.flutterwave.com/v3/billers/".$response['data'][0]['biller_code']."/items/".$response['data'][0]['item_code']."/payment",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS =>'{
    
    "country": "NG",
    "customer_id": "45076454185",
    "reference": "'.$reference_payment.'",
    "amount": "100"
 
}',
  CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        'Accept: application/json',
    "Authorization: Bearer FLWSECK_TEST-d0e85c930ac04fa693927227b3e3b2b2-X"
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;





//status

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.flutterwave.com/v3/bills/".$reference_payment."",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  
  CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        'Accept: application/json',
    "Authorization: Bearer FLWSECK_TEST-d0e85c930ac04fa693927227b3e3b2b2-X"
  ),
));

$response = json_decode(curl_exec($curl),true);

curl_close($curl);
print_r($response);


*/
