<?php

header("Content-type: application/json;meta-charset=UTF-8");

require_once "app_classes/Config_db.php";
require_once "app_classes/config_session.php";
require_once "app_classes/Class_app_two_factor_login.php";


//Checking if the user actual accessed the page from the right source
if ($_SERVER['REQUEST_METHOD'] === "POST") {

	//Getting the rquired properties to run the code
	$details=json_decode(file_get_contents("php://input"),true);

	$otp_pwd=$details['login_pin'];


	//Calling the class to process the code
	$authentication=new Two_factor_login($otp_pwd);



	//checking if the fields are empty
	if ($authentication->otp_error_handler()) {

		$error=[

			"Field is empty !",
		];

		echo json_encode($error);
		die();
		
	}



	//Checking if the user is valid

	if ($authentication->validation_user()) {
		
		$message=[

			"error"=>"Invalid user",
		];

		echo json_encode($message);

		die();
	}





	//Checking if the otp password is correct

	if ($authentication->validation_user_pin()) {
		
		$message=[

			"error"=>"You don't have login pin. click on reset to create one",
		];

		echo json_encode($message);

		die();
	}




	if (!$authentication->validation_token()) {
		

		$error=['Invalid token !'];

		echo json_encode($error);

		die();
	}


try{

	//If all the requirements are met

	if (!$authentication->otp_error_handler() && !$authentication->validation_user_pin() && !$authentication->validation_user() && $authentication->validation_token() && !$authentication->validation()) {

		die();
	
	}
}catch(PDOException $e){

			die("Connection:" . $e->getMessage());
}	


}else{
		$_SESSION['message']="Error Invalid access";

		echo json_encode($_SESSION['message'],JSON_NUMERIC_CHECK);

		die();
}