<?php
require_once "app_classes/Class_app_decode_token.php";

class Show_investment_plan extends Db_connect{





	//Public method for validating token
	public function token_verification(){


		//calling the jwt class
		$verify_token=new Jwt_decoded;

		if ($verify_token->decoded()) {

			return $verify_token->decoded();

		}


	}


	//public method to dislay the list of investment_plan

	public function display(){


		$sql="SELECT * FROM create_investment_plan ORDER BY id asc;";
		$result=parent::conn()->prepare($sql);

		$result->execute();

		if ($result->rowCount() > 0) {
				while ($rows=$result->fetch()) {

						$investment_plan=["investment"=>$rows];
					
					echo json_encode($investment_plan,JSON_NUMERIC_CHECK);

					
				}

		}


	}



public function empty_display(){


		$sql="SELECT * FROM create_investment_plan ORDER BY id asc;";
		$result=parent::conn()->prepare($sql);

		$result->execute();

		if ($result->rowCount() === 0) {
				return true;

		}


	}

}