<?php



class Reset_password extends Db_connect{


	private $uid;
	private $otp;



	public function __construct($uid,$otp){

		$this->uid=$uid;

		$this->otp=$otp;
	}



	//Checking if the field is empty
	public function error_handler(){
		//Checking the field is empty

		if (empty($this->otp) || empty($this->uid)) {
			
			return true;

		}
	}




	public function set_code(){

		//Setting the pin for login
		$const=[
			"const"=>12,
			];

		$auth=0;	

		$hashed_code=password_hash($this->otp, PASSWORD_BCRYPT,$const);

		$sqls="UPDATE users SET password=:password, reset_password=:reset_password WHERE username=:username Limit 1";
		$sql_result=parent::conn()->prepare($sqls);

		$sql_result->bindParam(":password",$hashed_code);
		$sql_result->bindParam(":reset_password",$auth);
		$sql_result->bindParam(":username",$this->uid);


		//Closing the database connection
		if ($sql_result->execute()) {
			
			$sqls=null;
			$sql_result=null;

			return true;
		}



	}






}