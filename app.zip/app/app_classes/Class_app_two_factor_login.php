<?php
require_once "load_env.php";

require_once "app_classes/Class_app_decode_token.php";
	

class Two_factor_login extends Db_connect{



	private $otp_pwd;	



	public function __construct($otp_pwd){


		$this->otp_pwd=$otp_pwd;
	}



	//Checking if the fields are empty

	public function otp_error_handler(){

		if (empty($this->otp_pwd)) {
			
			return true;
		}

	}






	//Checking if the user set login pin is correct

	public function validation_token(){

		//Calling the decoded token classname
		$decoded_token=new Jwt_decoded;

		return $decoded_token->decoded();


	}





	//Checking if the user exist

	public function validation_user(){

		$auth=1;
		$token=$this->validation_token();


		$sql_auth="SELECT * FROM users WHERE username=:username";
		$result_auth=parent::conn()->prepare($sql_auth);

		$result_auth->bindParam(":username",$token);

		$result_auth->execute();


		if ($result_auth->rowCount() === 0) {

				echo $token;
			return true;
		
		}



	}








	//Checking if the user set login pin is correct

	public function validation_user_pin(){

		$auth=1;
		$token=$this->validation_token();

		$sql_auth="SELECT * FROM users WHERE username=:username AND authenticate=:authenticate";
		$result_auth=parent::conn()->prepare($sql_auth);

		$result_auth->bindParam(":username",$token);

		$result_auth->bindParam(":authenticate",$auth);

		$result_auth->execute();


		if ($result_auth->rowCount() === 0) {

				
			return true;
		
		}



	}






	//Checking if the password is correct

	public function validation(){

		$auth=1;
		$token=$this->validation_token();

		$sql_auth="SELECT * FROM users WHERE username=:username AND authenticate=:authenticate Limit 1";
		$result_auth=parent::conn()->prepare($sql_auth);
		
		$result_auth->bindParam(":username",$token);

		$result_auth->bindParam(":authenticate",$auth);

		$result_auth->execute();


		if ($result_auth->rowCount() > 0) {

				if ($rows=$result_auth->fetch()) {

					$verify=password_verify($this->otp_pwd,$rows['authentication_code']);

					//CHECKING IF IT IS TRUE
					if ($verify === false) {

							$error=['Invalid pin !'];

							echo json_encode($error);

							die();

					}elseif ($verify === true) {


						//Getting the wallet information of the user And Static bank details
					$data=new Load_me;

	

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.flutterwave.com/v3/payout-subaccounts/".$rows['acct_reference']."/static-account",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  
  CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        'Accept: application/json',
    "Authorization: Bearer ".$data->display_me()['key_me'].""
  ),
));

$response = json_decode(curl_exec($curl),true);

curl_close($curl);




	//Fetching the available balance of the user

	$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.flutterwave.com/v3/payout-subaccounts/".$rows['acct_reference']."/balances",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
 
  CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        'Accept: application/json',
    "Authorization: Bearer ".$data->display_me()['key_me'].""
  ),
));

$responded = json_decode(curl_exec($curl),true);

curl_close($curl);





	//Fetching transaction history
	
		//calculating the transaction date from up to 30days
		$date=date('Y-m-d');

		$minus_date=date('Y-m-d',strtotime("-90days"));


		
		$curls = curl_init();

		curl_setopt_array($curls, array(
 		 CURLOPT_URL => "https://api.flutterwave.com/v3/payout-subaccounts/".$rows['acct_reference']."/transactions?from=".$minus_date."&to=".$date."",
 	 	CURLOPT_RETURNTRANSFER => true,
 	 	CURLOPT_FOLLOWLOCATION => true,
  		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  		CURLOPT_CUSTOMREQUEST => "GET",
  		 CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        'Accept: application/json',
    	"Authorization: Bearer ".$data->display_me()['key_me'].""
 	 ),
	));

	$responses = json_decode(curl_exec($curls),true);

	curl_close($curls);



						$data = [
							"user"=>$rows,
							"Bank_deposit_information"=>$response,
							"Available_balance"=>$responded,
							"transaction_history"=>$responses
							];

						echo json_encode($data);
						die();
											
					}//else1



				}//if2

		
		}//if1




	}






}