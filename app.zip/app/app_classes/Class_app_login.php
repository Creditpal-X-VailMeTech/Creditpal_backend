<?php


class User_login_validation extends Db_connect{

	//properties 
	private $uid;
	private $pwd;

	//constructor
	public function __construct($uid,$pwd){

		$this->uid=$uid;

		$this->pwd=$pwd;

	}



	//function to handle error
	public function login_error_handler(){

		if(empty($this->uid) || empty($this->pwd)){

			//Then return true that one of the field is empty
			return true;
		}
	}



	//function to login the user
	public function logged_in(){

		$validation=1;
		$status="enabled";

		$sql="SELECT * FROM users WHERE username=:username AND verified=:verified AND account_status=:account_status;";
		$result=parent::conn()->prepare($sql);

		$result->bindParam(":username",$this->uid);
		$result->bindParam(":verified",$validation);
		$result->bindParam(":account_status",$status);

		$result->execute();

		if($result->rowCount() > 0){

			if($rows=$result->fetch()){

				$hashed_pwd=$rows['password'];

				$decrypt_pwd=password_verify($this->pwd,$hashed_pwd);

				//Cheking if the password is true or not 

				if($decrypt_pwd === false){
					//return true for incorrect password
					return false;

				}elseif($decrypt_pwd === true){
					//Return false for correct password
					
					return $rows['username'];
				}

			}


		}else{
			//INVALID USERNAME
			return false;
		}

	}



}