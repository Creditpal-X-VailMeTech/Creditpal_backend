<?php

class Verify_email_rest_password extends Db_connect{
	
	private $uid;
	private $code;


	public function __construct($uid,$code){

		$this->uid=$uid;
		$this->code=$code;


	}





	//public method for the empty fields
	public function error_handle_verification(){

		if (empty($this->uid) || empty($this->code)) {
			
			return true;
		}

	}




	//public method to validate the code submitted to the users email
	public function validate(){
		

		$sql="SELECT * FROM users WHERE username=:username";
		$result=parent::conn()->prepare($sql);

		$result->bindParam(":username",$this->uid);

		$result->execute();

		if ($result->rowCount() === 0) {

			return true;

		}

	}










//public method to validate the code submitted by the user is correct
	public function validates_pin(){
		

		$sql="SELECT * FROM users WHERE username=:username AND reset_password=:reset_password";
		$result=parent::conn()->prepare($sql);

		$result->bindParam(":username",$this->uid);
		$result->bindParam(":reset_password",$this->code);

		$result->execute();

		if ($result->rowCount() > 0) {

					$reset=0;

				$update_user="UPDATE users SET reset_password=? WHERE username=? LIMIT 1;";
				$update_result=parent::conn()->prepare($update_user);


				if($update_result->execute([$reset,$this->uid])){

					
					
					$message=[
						"message"=>"Verification successful, Please proceed to reset your password",
						"user" => $this->uid

					];
		
					echo json_encode($message,JSON_NUMERIC_CHECK);
					die();

				}


		}//if

	}



}