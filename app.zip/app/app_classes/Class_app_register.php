<?php

class App_register_user extends Db_connect{


	private $first_name;
	private $last_name;
	private $bvn;
	private $uid;
	private $pwd;


	//Constructor

	public function __construct($first_name,$last_name,$bvn,$uid,$pwd){

		$this->first_name=$first_name;
		$this->last_name=$last_name;
		$this->bvn=$bvn;
		$this->uid=$uid;
		$this->pwd=$pwd;


	}


	//Method to handle errors
	public function handle_user_error(){

		//If the field is empty
		if (empty($this->first_name) || empty($this->last_name) || empty($this->bvn) || empty($this->uid) || empty($this->pwd)) {
			
			return true;
		}

	}


	//method to validate character
	public function character(){

		if (!preg_match("/^[a-z A-Z]*$/",$this->first_name) || !preg_match("/^['a-z A-Z']*$/",$this->last_name)) {
				
				echo "hooo";
				return true;

		}

	}



	//Methode to handle if the email entered is valid
	public function validate_email(){

		if (!filter_var($this->uid,FILTER_VALIDATE_EMAIL)) {
			
			return true;

		}


	}


	//Method to check if the email already exist in the database

	public function user_already_exist(){

		$sql="SELECT * FROM users WHERE username=:username";
		$result=parent::conn()->prepare($sql);

		$result->bindParam(":username",$this->uid);

		$result->execute();

		if ($result->rowCount() > 0) {
			
			//closing database connection
			$sql=null;
			$result=null;

			return true;

		}

	}








	//Public method for verifying bnv
	public function verify_bvn(){


		$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.flutterwave.com/v3/bvn/verifications',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS =>'{

  	 "bvn": "'.$this->bvn.'",
    "firstname": "'.$this->first_name.'",
    "lastname": "'.$this->last_name.'"
 

}',
  CURLOPT_HTTPHEADER => array(
	'Content-Type: application/json',

   'Authorization: Bearer FLWSECK_TEST-d0e85c930ac04fa693927227b3e3b2b2-X'
  ),
));

$response = curl_exec($curl);

curl_close($curl);

	return json_decode($response,true);


	}







	//publc function to verify bvn consent
	public function verify_bvn_consent(){

		$reference=$this->verify_bvn()['data']['reference'];

		$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.flutterwave.com/v3/bvn/verifications/".$reference."",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        'Accept: application/json',
    "Authorization: Bearer FLWSECK_TEST-d0e85c930ac04fa693927227b3e3b2b2-X"
  ),
));

$response = curl_exec($curl);

curl_close($curl);

	return json_decode($response,true);



	}







	//Method to hash the password
	public function encrypt_pwd(){

		$encrypt=[

			"cont"=>12
		];

	
		$encryption=password_hash($this->pwd,PASSWORD_BCRYPT,$encrypt);

		return $encryption;


	}



	

}