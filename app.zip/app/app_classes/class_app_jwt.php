<?php
require_once "load_env.php";


use Firebase\JWT\JWT;
use Firebase\JWT\Key;


class JTW extends Db_connect{


	public function jwt(){
					


			$authentication=apache_request_headers();


						if (isset($authentication['Authorization'])) {

							//GEtting the header token
							$token=$authentication['Authorization'];
                            $data=new Load_me;

							//Seperating the Bearer and the token

							$jwt=str_replace("Bearer ","", $token);
							$key = "".$data->display_me()['token_me']."";
							
							$decoded=JWT::decode($jwt, new Key($key,'HS256'));

							

								try {
									
									if ($decoded) {
									

									$extract_data=json_encode($decoded);

									return $extract_data;

									}
								} catch (PDOException $e) {
									
									die("Connection Failed:" . $e->getMessage());
								}

								
							



						}



	}


}