<?php
require_once "app_classes/Class_app_decode_token.php";


class Add_balance extends Db_connect{
	
	//properties

	
	private $amount;


	//constuctor
	public function __construct(int $amount){

		
		$this->amount=$amount;

	}


	//public method

	public function error_handle_deposits(){

		if (empty($this->amount)) {
			
			return true;
		}
	}





	//Verify Bearer  token

	public function token_verification(){


		//calling the jwt class
		$verify_token=new Jwt_decoded;

		if ($verify_token->decoded()) {

			return $verify_token->decoded();

		}


	}



	//Verify the user

	public function validate_user(){

			$uid=$this->token_verification();

			//Get users details

			$sql="SELECT * FROM users WHERE username=:username;";
			$result=parent::conn()->prepare($sql);

			$result->bindParam(":username",$uid);
			$result->execute();

			if ($result->rowCount() === 0) {
					
					
				return true;



			}
			



	}




	//public method to handle the payment initialization
	public function process_payment(){
			$uid=$this->token_verification();

			
							
			$date=date('Y-m-d H:i:s');

			//Update the table and credit user
			$sql_credit="INSERT INTO credit_balance(user_account,amount_to_balance,added_date)VALUES(:username,:amount,:timing);";

			$result_credit=parent::conn()->prepare($sql_credit);
			$result_credit->bindParam(":username",$uid);
			$result_credit->bindParam(":amount",$this->amount);
			$result_credit->bindParam(":timing",$date);
			$result_credit->execute();



			//for transaction table
			$type="Deposit";
			$status="Successful";

			$sql_credit_tran="INSERT INTO transactions(transaction_type,transaction_amount,transaction_user,transaction_status,transaction_date)VALUES(:type,:amount,:username,:status,:timing);";

			$result_credit_tran=parent::conn()->prepare($sql_credit_tran);
			$result_credit_tran->bindParam(":type",$type);
			$result_credit_tran->bindParam(":amount",$this->amount);
			$result_credit_tran->bindParam(":username",$uid);
			$result_credit_tran->bindParam(":status",$status);
			$result_credit_tran->bindParam(":timing",$date);
			$result_credit_tran->execute();


			//Update user's balance
			$sql_credit_user="UPDATE users SET user_balance = user_balance + $this->amount WHERE username=:username;";

			$result_credit_user=parent::conn()->prepare($sql_credit_user);
			$result_credit_user->bindParam(":username",$uid);
			$result_credit_user->execute();

			if ($result_credit_user->execute()) {
				
				$sql_credit_user=null;
				$result_credit_user=null;
			}

			
			return true;



					

			



		

	}








}