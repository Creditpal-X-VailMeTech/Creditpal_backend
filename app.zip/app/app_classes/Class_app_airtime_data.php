<?php
require_once "app_classes/Class_app_decode_token.php";


class Buy_data_and_airtime extends Db_connect{
	
	//properties
	private $phone;
	private $amount;
	private $bank;
	private $acct_number;
	private $note;
	private $ref;

	//constuctor
	public function __construct($phone,int $amount,$bank,$acct_number,$note,$ref){

		$this->phone=$phone;
		$this->amount=$amount;
		$this->bank=$bank;
		$this->acct_number=$acct_number;
		$this->note=$note;
		$this->ref=$ref;


	}




		//Public method for validating token
	public function token_verification(){


		//calling the jwt class
		$verify_token=new Jwt_decoded;

		if ($verify_token->decoded()) {

			return $verify_token->decoded();

		}


	}




	//public method for checking if the fields are empty
	public function error_handle_airtime(){

		if (empty($this->phone) || empty($this->amount)) {
			
			return true;
		}


	}



	//check user
	public function check_user(){
		 $user=$this->token_verification();

		$sql="SELECT * FROM users WHERE username=:username;";
			$result=parent::conn()->prepare($sql);
			$result->bindParam(":username",$user);

			$result->execute();


			if ($result->rowCount() === 0) {

				return true;

			}


	}





	//public method for checking processing the data
	public function process_airtime_for_user(){

		 $user=$this->token_verification();

			
			$sql="SELECT * FROM users WHERE username=:username;";
			$result=parent::conn()->prepare($sql);
			$result->bindParam(":username",$user);

			$result->execute();


			if ($result->rowCount() > 0) {
					
				if ($rows=$result->fetch()) {
					
											//Getting the wallet information of the user And Static bank details
								$data=new Load_me;


							$curl = curl_init();

							curl_setopt_array($curl, array(
 							 CURLOPT_URL => "https://api.flutterwave.com/v3/payout-subaccounts/".$rows['acct_reference']."/static-account",
 							 CURLOPT_RETURNTRANSFER => true,
 							 CURLOPT_ENCODING => "",
 							 CURLOPT_MAXREDIRS => 10,
 							 CURLOPT_TIMEOUT => 0,
 							 CURLOPT_FOLLOWLOCATION => true,
 							 CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
 							 CURLOPT_CUSTOMREQUEST => "GET",
  
 							 CURLOPT_HTTPHEADER => array(
 							       "Content-Type: application/json",
 							       'Accept: application/json',
 							   "Authorization: Bearer ".$data->display_me()['key_me'].""
							),
							));

							$response = json_decode(curl_exec($curl),true);

							curl_close($curl);






						//Fetching the available balance of the user

						$curl = curl_init();

					curl_setopt_array($curl, array(
  					CURLOPT_URL => "https://api.flutterwave.com/v3/payout-subaccounts/".$rows['acct_reference']."/balances",
  					CURLOPT_RETURNTRANSFER => true,
  					CURLOPT_ENCODING => "",
  					CURLOPT_MAXREDIRS => 10,
  					CURLOPT_TIMEOUT => 0,
  					CURLOPT_FOLLOWLOCATION => true,
  					CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  					CURLOPT_CUSTOMREQUEST => "GET",
 
  					CURLOPT_HTTPHEADER => array(
  					      "Content-Type: application/json",
  					      'Accept: application/json',
  					  "Authorization: Bearer ".$data->display_me()['key_me'].""
  					),
					));

				$responded = json_decode(curl_exec($curl),true);

					curl_close($curl);










						//Checking if the balance is withdrawable

					if (floor($responded['data']['available_balance']) > $this->amount && !floor($responded['data']['available_balance']) <= 0) {



						

						//Then process the payment



						$date=date('Y-m-d H:i:s');


						//Insert the data into the database
						$sql_insert="INSERT INTO telecommunication(user_account,network,amount,purchase_date)Values(?,?,?,?);";

						$sql_result=parent::conn()->prepare($sql_insert);


						
						if ($sql_result->execute([$user,$this->phone,$this->amount,$date])) {
							
							$sql_insert=null;
							$sql_result=null;


						}





							

	//withdrawing account test
					$data=new Load_me;


					$curl = curl_init();

					curl_setopt_array($curl, array(
 					 CURLOPT_URL => "https://api.flutterwave.com/v3/transfers",
					  CURLOPT_RETURNTRANSFER => true,
					  CURLOPT_ENCODING => "",
					  CURLOPT_MAXREDIRS => 10,
					  CURLOPT_TIMEOUT => 0,
					  CURLOPT_FOLLOWLOCATION => true,
					  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					  CURLOPT_CUSTOMREQUEST => "POST",
					  CURLOPT_POSTFIELDS =>'{
					
					    "account_bank": "'.$this->bank.'",
					  "account_number": "'.$this->acct_number.'",
					  "amount": "'.$this->amount.'",
					  "narration": "'.$this->note.'",
					  "currency": "NGN",
					  "reference": "'.$this->ref.'",
					  "debit_currency": "NGN",
					 "debit_subaccount": "'.$rows['acct_reference'].'"

				}',
				  CURLOPT_HTTPHEADER => array(
				        "Content-Type: application/json",
				        'Accept: application/json',
				    "Authorization: Bearer ".$data->display_me()['key_me'].""
				  ),
				));

				$response = json_decode(curl_exec($curl),true);

				curl_close($curl);



							return true;



					}//if amount

				}//if fetch	


			}



		







	}









}