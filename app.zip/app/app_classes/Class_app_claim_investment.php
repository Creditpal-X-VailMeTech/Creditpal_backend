<?php

require_once "app_classes/Class_app_decode_token.php";


class Redeem_investment extends Db_connect{

	//properties

	private $investment_id;


	//constructor 

	public function __construct($investment_id){


		$this->investment_id=$investment_id;


	}




	//public method to check for empty field

	public function error_handle_request(){

		if (empty($this->investment_id)) {
			
			return true;
		}
	}



	//Public method for validating token
	public function token_verification(){


		//calling the jwt class
		$verify_token=new Jwt_decoded;

		if ($verify_token->decoded()) {

			return $verify_token->decoded();

		}


	}



	//public method to check if the user exist
	public function check_user(){
			$user=$this->token_verification();

			$sql_redeem="SELECT * FROM users WHERE username=:username;";

			$result_redeem=parent::conn()->prepare($sql_redeem);

			$result_redeem->bindParam(':username',$user);

			$result_redeem->execute();

			if ($result_redeem->rowCount() === 0) {

				return true;
			}



	}



	//public method to check if the user is valid with the investment id
	public function check_user_and_investment_id(){

		$user=$this->token_verification();


		$sql="SELECT * FROM investment WHERE id=:id AND account_user=:username;";

		$result=parent::conn()->prepare($sql);

		$result->bindParam(":id",$this->investment_id);
		$result->bindParam(":username",$user);


		if ($result->execute() && $result->rowCount() > 0) {
			
			if ($rows=$result->fetch()) {
					
					$expired_date=str_replace("-","",$rows['payback_date']);

					$start_date=str_replace("-","",$rows['investment_date']);


					//Calculating to see if the date is actually compeleted

					if ($expired_date - $start_date <= 0) {
							
						$status="Complete";

						$update_investment_status="UPDATE investment SET investment_status=? WHERE account_user=? LIMIT 1;";
						$update_result=parent::conn()->prepare($update_investment_status);

						if ($update_result->execute([$status,$user])) {
							


								//Then email the admin for him to know someone wish to withdraw his investment

								$to="email@gmail.com";
								$subject="Loan Application";
								$body="Yo someone applied for loan";
								$header="From:<noreply@creditpal.com.ng>" . "\r\n";
								$header.="MIME-VERSION: 1.0" . "\r\n";
								$header.="Content-type:text/html;meta-charset=UFT-8" . "\r\n";

								mail($to, $subject, $body,$header);

								$update_investment_status=null;
								$update_result=null;

								return true;

						}



					}elseif (!$expired_date - $start_date <= 0) {
							
						$message=["message"=>"You are yet to reach the end date for your investment, please wait for the payback date"];

						echo json_encode($message,JSON_NUMERIC_CHECK);
						die();


					}//calculate



			}//fetch


		}


	}


}