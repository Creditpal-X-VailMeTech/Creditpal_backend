<?php

class Verify_email extends Db_connect{
	
	private $uid;
	private $code;


	public function __construct($uid,$code){

		$this->uid=$uid;
		$this->code=$code;


	}





	//public method for the empty fields
	public function error_handle_verification(){

		if (empty($this->uid) || empty($this->code)) {
			
			return true;
		}

	}




	//public method to validate the code submitted to the users email
	public function validate(){
		

		$sql="SELECT * FROM users WHERE username=:username";
		$result=parent::conn()->prepare($sql);

		$result->bindParam(":username",$this->uid);

		$result->execute();

		if ($result->rowCount() === 0) {

			return true;

		}

	}










//public method to validate the code submitted by the user is correct
	public function validates_pin(){
		

		$sql="SELECT * FROM users WHERE username=:username AND verification_code=:verification_code";
		$result=parent::conn()->prepare($sql);

		$result->bindParam(":username",$this->uid);
		$result->bindParam(":verification_code",$this->code);

		$result->execute();

		if ($result->rowCount() > 0) {
			
						
						$v_code=0;
						$v_verified=1;

						//Update the users status
						$sql_update="UPDATE users SET verification_code=:verification_code, verified=:verified WHERE username=:username Limit 1;";

						$result_update=parent::conn()->prepare($sql_update);
						$result_update->bindParam(":verification_code",$v_code);
						$result_update->bindParam(":verified",$v_verified);
						$result_update->bindParam(":username",$this->uid);

						$result_update->execute();


		try {
			
				$message=[
				
				"message"=>"success",
				"user"=>$this->uid
			];

			echo json_encode($message,JSON_NUMERIC_CHECK);

		

		} catch (PDOException $e) {
			die("Connection: " . $e->getMessage());
		}

			return true;

			die();

		}//if

	}



}