<?php
require_once "load_env.php";

require_once "app_classes/Class_app_decode_token.php";

class Withdraw_to_bank extends Db_connect{


	//Properties

	private $amount;
	private $acct_number;
	private $bank;
	private $note;
	private $login_pin;


	//constructor
	public function __construct(int $amount,$acct_number,$bank,$note,$login_pin){

		$this->amount=$amount;
		$this->acct_number=$acct_number;
		$this->bank=$bank;
		$this->note=$note;
		$this->login_pin=$login_pin;

	}






	//Public method for validating token
	public function token_verification(){


		//calling the jwt class
		$verify_token=new Jwt_decoded;

		if ($verify_token->decoded()) {

			return $verify_token->decoded();

		}


	}




	//Public method
	public function empty_error_check(){

		//checking if the required fields are empty
		if (empty($this->amount) || empty($this->acct_number) || empty($this->bank)  || empty($this->note)  ||empty($this->login_pin)) {
			
			return true;

		}

	}



	//public method to check if the user exist
	public function check_user(){


			$authenticate=$this->token_verification();

		
		//fectching the user's details from the table

		$sql="SELECT * FROM users WHERE username=:username;";
		$result=parent::conn()->prepare($sql);

		$result->bindParam(':username',$authenticate);
		$result->execute();


		if ($result->rowCount() === 0) {
			
				return true;

		}





	}






	//public method to check if the login pin is correct
	public function check_login_pin(){


			$authenticate=$this->token_verification();

		
		//fectching the user's details from the table

		$sql="SELECT * FROM users WHERE username=:username;";
		$result=parent::conn()->prepare($sql);

		$result->bindParam(':username',$authenticate);
		$result->execute();


		if ($result->rowCount() > 0) {
			
				if ($row=$result->fetch()) {
					
					$dehashed=password_verify($this->login_pin, $row['authentication_code']);

					if ($dehashed === false) {
						
						return false;
					}elseif ($dehashed === true) {

						return true;
					}
				}

		}





	}





	//public method to verify balance
	public function check_balance(){

		$authenticate=$this->token_verification();

		
		//fectching the user's details from the table

		$sql="SELECT * FROM users WHERE username=:username;";
		$result=parent::conn()->prepare($sql);

		$result->bindParam(':username',$authenticate);
		$result->execute();


		if ($result->rowCount() > 0) {
			
				if ($rows=$result->fetch()) {

						//Getting the wallet information of the user And Static bank details
								$data=new Load_me;


							$curl = curl_init();

							curl_setopt_array($curl, array(
 							 CURLOPT_URL => "https://api.flutterwave.com/v3/payout-subaccounts/".$rows['acct_reference']."/static-account",
 							 CURLOPT_RETURNTRANSFER => true,
 							 CURLOPT_ENCODING => "",
 							 CURLOPT_MAXREDIRS => 10,
 							 CURLOPT_TIMEOUT => 0,
 							 CURLOPT_FOLLOWLOCATION => true,
 							 CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
 							 CURLOPT_CUSTOMREQUEST => "GET",
  
 							 CURLOPT_HTTPHEADER => array(
 							       "Content-Type: application/json",
 							       'Accept: application/json',
 							   "Authorization: Bearer ".$data->display_me()['key_me'].""
							),
							));

							$response = json_decode(curl_exec($curl),true);

							curl_close($curl);






						//Fetching the available balance of the user

						$curl = curl_init();

					curl_setopt_array($curl, array(
  					CURLOPT_URL => "https://api.flutterwave.com/v3/payout-subaccounts/".$rows['acct_reference']."/balances",
  					CURLOPT_RETURNTRANSFER => true,
  					CURLOPT_ENCODING => "",
  					CURLOPT_MAXREDIRS => 10,
  					CURLOPT_TIMEOUT => 0,
  					CURLOPT_FOLLOWLOCATION => true,
  					CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  					CURLOPT_CUSTOMREQUEST => "GET",
 
  					CURLOPT_HTTPHEADER => array(
  					      "Content-Type: application/json",
  					      'Accept: application/json',
  					  "Authorization: Bearer ".$data->display_me()['key_me'].""
  					),
					));

				$responded = json_decode(curl_exec($curl),true);

					curl_close($curl);








						//Checking if the balance is withdrawable

					if (floor($responded['data']['available_balance']) > $this->amount && !floor($responded['data']['available_balance']) <= 0) {

					//if the condition is met

				

					return true;



					}

				}



		}


	}





	//Public method for withdrawal
	public function verify_balance_and_withdraw(){

				
//public method to verify balance

		$authenticate=$this->token_verification();

		
		//fectching the user's details from the table

		$sql="SELECT * FROM users WHERE username=:username;";
		$result=parent::conn()->prepare($sql);

		$result->bindParam(':username',$authenticate);
		$result->execute();


		if ($result->rowCount() > 0) {
			
				if ($rows=$result->fetch()) {

					$reference_payment=md5(time());



				$date=date('Y-m-d H:i:s');
				$authenticate=$this->token_verification();


					//Inserting the transaction details to the table
							
						$type="Withdrawal";
						$status="successful";

						$sql_tran="INSERT INTO transactions(transaction_type,transaction_amount,transaction_user,transaction_status,transaction_date,ref)VALUES(:type,:amount,:username,:status,:timing,:ref);";

						$result_tran=parent::conn()->prepare($sql_tran);

						$result_tran->bindParam(":type",$type);
						$result_tran->bindParam(":amount",$this->amount);
						$result_tran->bindParam(":username",$authenticate);
						$result_tran->bindParam(":status",$status);
						$result_tran->bindParam(":timing",$date);
						$result_tran->bindParam(":ref",$reference_payment);
						

						//Closing the database

						if ($result_tran->execute()) {
							
							$sql_tran=null;
							$result_tran=null;
						}


					//Inserting the transaction details to the table

							$sql_trans="INSERT INTO bank_transfer(account_user,account_number,bank,amount,note,transfer_status,transfer_date,ref)VALUES(:user,:acct_number,:bank,:amount,:note,:status,:timing,:ref);";

						$result_trans=parent::conn()->prepare($sql_trans);

						$result_trans->bindParam(":user",$authenticate);
						$result_trans->bindParam(":acct_number",$this->acct_number);
						$result_trans->bindParam(":bank",$this->bank);
						$result_trans->bindParam(":amount",$this->amount);
						$result_trans->bindParam(":note",$this->note);
						$result_trans->bindParam(":status",$status);
						$result_trans->bindParam(":timing",$date);
						$result_trans->bindParam(":ref",$reference_payment);


							//Closing the database

						if ($result_trans->execute()) {
							
							$sql_trans=null;
							$result_trans=null;
						}





					

	//withdrawing account test
					$data=new Load_me;


					$curl = curl_init();

					curl_setopt_array($curl, array(
 					 CURLOPT_URL => "https://api.flutterwave.com/v3/transfers",
					  CURLOPT_RETURNTRANSFER => true,
					  CURLOPT_ENCODING => "",
					  CURLOPT_MAXREDIRS => 10,
					  CURLOPT_TIMEOUT => 0,
					  CURLOPT_FOLLOWLOCATION => true,
					  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					  CURLOPT_CUSTOMREQUEST => "POST",
					  CURLOPT_POSTFIELDS =>'{
					
					    "account_bank": "'.$this->bank.'",
					  "account_number": "'.$this->acct_number.'",
					  "amount": "'.$this->amount.'",
					  "narration": "'.$this->note.'",
					  "currency": "NGN",
					  "reference": "'.$reference_payment.'",
					  "debit_currency": "NGN",
					 "debit_subaccount": "'.$rows['acct_reference'].'"

				}',
				  CURLOPT_HTTPHEADER => array(
				        "Content-Type: application/json",
				        'Accept: application/json',
				    "Authorization: Bearer ".$data->display_me()['key_me'].""
				  ),
				));

				$response = json_decode(curl_exec($curl),true);

				curl_close($curl);


						
				$message=[

					"info"=>$response

					];

					echo json_encode($message,JSON_NUMERIC_CHECK);





				}



		}



	}





}