<?php

require_once "load_env.php";

require_once "app_classes/Class_app_decode_token.php";

/**
 * 
 */
class Create_investment extends Db_connect{
	
	private $i_name;
	private $i_plan;
	private $i_duration;
	private $i_amount;
	private $i_estimated_returns;
	private $note;
	private $pay_day;

	private $bank;
	private $acct_number;
	private $ref;

	public function __construct($i_name,$i_plan, $i_duration,int $i_amount,int $i_estimated_returns,$note, $pay_day,$bank,$acct_number,$ref){
		
		$this->i_name=$i_name;
		$this->i_plan=$i_plan;
		$this->i_duration=$i_duration;
		$this->i_amount=$i_amount;
		$this->i_estimated_returns=$i_estimated_returns;
		$this->note=$note;
		$this->pay_day=$pay_day;
		$this->bank=$bank;
		$this->acct_number=$acct_number;
		$this->ref=$ref;
	}



		//Public method for validating token
	public function token_verification(){


		//calling the jwt class
		$verify_token=new Jwt_decoded;

		if ($verify_token->decoded()) {

			return $verify_token->decoded();

		}


	}



	//Method to check if the fields are empty
	public function error_handle_investment(){

		if (empty($this->i_name) || empty($this->i_plan) || empty($this->i_duration) || empty($this->i_amount) || empty($this->i_estimated_returns) || empty($this->note) || empty($this->pay_day)) {
			

			return true;
		}

	}





	//check user
	public function check_user(){
		 $user=$this->token_verification();

		$sql="SELECT * FROM users WHERE username=:username;";
			$result=parent::conn()->prepare($sql);
			$result->bindParam(":username",$user);

			$result->execute();


			if ($result->rowCount() === 0) {

				return true;

			}


	}



	//public method to determin if the user token is valid
	public function create_investment_plan(){

		 $user=$this->token_verification();


			$sql="SELECT * FROM users WHERE username=:username;";

			$result=parent::conn()->prepare($sql);

			$result->bindParam(":username",$user);

			$result->execute();

			if ($result->rowCount() > 0) {
				
				if ($balance=$result->fetch()) {




	//Getting the wallet information of the user And Static bank details
								$data=new Load_me;


							$curl = curl_init();

							curl_setopt_array($curl, array(
 							 CURLOPT_URL => "https://api.flutterwave.com/v3/payout-subaccounts/".$balance['acct_reference']."/static-account",
 							 CURLOPT_RETURNTRANSFER => true,
 							 CURLOPT_ENCODING => "",
 							 CURLOPT_MAXREDIRS => 10,
 							 CURLOPT_TIMEOUT => 0,
 							 CURLOPT_FOLLOWLOCATION => true,
 							 CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
 							 CURLOPT_CUSTOMREQUEST => "GET",
  
 							 CURLOPT_HTTPHEADER => array(
 							       "Content-Type: application/json",
 							       'Accept: application/json',
 							   "Authorization: Bearer ".$data->display_me()['key_me'].""
							),
							));

							$response = json_decode(curl_exec($curl),true);

							curl_close($curl);






						//Fetching the available balance of the user

						$curl = curl_init();

					curl_setopt_array($curl, array(
  					CURLOPT_URL => "https://api.flutterwave.com/v3/payout-subaccounts/".$balance['acct_reference']."/balances",
  					CURLOPT_RETURNTRANSFER => true,
  					CURLOPT_ENCODING => "",
  					CURLOPT_MAXREDIRS => 10,
  					CURLOPT_TIMEOUT => 0,
  					CURLOPT_FOLLOWLOCATION => true,
  					CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  					CURLOPT_CUSTOMREQUEST => "GET",
 
  					CURLOPT_HTTPHEADER => array(
  					      "Content-Type: application/json",
  					      'Accept: application/json',
  					  "Authorization: Bearer ".$data->display_me()['key_me'].""
  					),
					));

				$responded = json_decode(curl_exec($curl),true);

					curl_close($curl);




						if ($responded['status'] === "success") {
						// code...

					//Checking if the user has sufficient balance to access the plan
					if (floor($responded['data']['available_balance']) > 0 && floor($responded['data']['available_balance']) > $this->i_amount) {

						$date=date('Y-m-d H:i:s');




				//debiting user to create investment loan to the admin account test


					$curl = curl_init();

					curl_setopt_array($curl, array(
 					 CURLOPT_URL => "https://api.flutterwave.com/v3/transfers",
					  CURLOPT_RETURNTRANSFER => true,
					  CURLOPT_ENCODING => "",
					  CURLOPT_MAXREDIRS => 10,
					  CURLOPT_TIMEOUT => 0,
					  CURLOPT_FOLLOWLOCATION => true,
					  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					  CURLOPT_CUSTOMREQUEST => "POST",
					  CURLOPT_POSTFIELDS =>'{
					
					    "account_bank": "'.$this->bank.'",
					  "account_number": "'.$this->acct_number.'",
					  "amount": "'.$this->i_amount.'",
					  "narration": "'.$this->note.'",
					  "currency": "NGN",
					  "reference": "'.$this->ref.'",
					  "debit_currency": "NGN",
					 "debit_subaccount": "'.$balance['acct_reference'].'"

				}',
				  CURLOPT_HTTPHEADER => array(
				        "Content-Type: application/json",
				        'Accept: application/json',
				    "Authorization: Bearer ".$data->display_me()['key_me'].""
				  ),
				));

				$response = json_decode(curl_exec($curl),true);

				curl_close($curl);











					if ($response['status'] === "success") {


						$user=$this->token_verification();

						//Deduct the user's account balance

						$sql_update="UPDATE users SET investment_balance=investment_balance + ? WHERE username=? LIMIT 1;";
						$result_sql=parent::conn()->prepare($sql_update);

						$result_sql->execute([$this->i_estimated_returns,$user]);


						
						//Then proceed to create the plan for the user
						$status="Active";

						$sql_create_plan="INSERT INTO investment(account_user,investment_name,investment_plan,investment_duration,estimated_returns,payback_date,investment_status,investment_date)VALUES(:account_user,:investment_name,:investment_plan,:investment_duration,:estimated_returns,:payback_date,:investment_status,:date_invested);";

						$smt=parent::conn()->prepare($sql_create_plan);

						$smt->bindParam(":account_user",$user);
						$smt->bindParam(":investment_name",$this->i_name);
						$smt->bindParam(":investment_plan",$this->i_plan);
						$smt->bindParam(":investment_duration",$this->i_duration);
						$smt->bindParam(":estimated_returns",$this->i_estimated_returns);
						$smt->bindParam(":payback_date",$this->pay_day);
						$smt->bindParam(":investment_status",$status);
						$smt->bindParam(":date_invested",$date);


						if ($smt->execute()) {
							
							$sql_create_plan=null;
							$smt=null;
						}


						$investment_details_return=[

							"name"=>$this->i_name,
							"plan"=>$this->i_plan,
							"duration"=>$this->i_duration,
							"amount_invested"=>$this->i_amount,
							"estimated_returns"=>$this->i_estimated_returns,
							"payback_date"=>$this->pay_day,
							"message"=>"You have successfully created an investment plan",

						];

						echo json_encode($investment_details_return,JSON_NUMERIC_CHECK);
						die();



					}elseif ($response['status'] === "error") {
						
								$error=["error"=>" An error occured"];

								return json_encode($error);
								die();	
					}

					}elseif(floor($responded['data']['available_balance']) === 0 || floor($responded['data']['available_balance']) < $this->i_amount){


						$message=["message"=>"Insufficient fund"];
						echo json_encode($message);
						die();

					}//if balance check

					
					}elseif ($responded['status'] === "error") {
						
								$error=["error"=>" An error occured"];

								return json_encode($error);
								die();	
					}

				}//if fetch

			}//if for exist
	

			



	}
}