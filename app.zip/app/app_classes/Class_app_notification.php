<?php

require_once "app_classes/class_app_jwt.php";



class Notification extends Db_connect{
	
	//Properties
	private $uid;

	//Constructor
	public function __construct($uid){
		
		$this->uid=$uid;

	}



	public function get_selected_notification(){

		$verified=new JWT;

		//Checking if the user is accessing the page with the right token

		if ($verified->jwt() == $this->uid) {

				
				$sql_note="SELECT * FROM notification WHERE account_user=:username";

				$result_note=parent::conn()->prepare($sql_note);

				$result_note->bindParam(":username",$this->uid);

				$result_note->execute();

				if ($result_note->rowCount() > 0) {
						
						if($notify=$result_note->fetch(PDO::FETCH_ASSOC){

							//RETURN THE ARRAY OBJECT FOR THE USER
							return json_encode($notify,JSON_NUMERIC_CHECK);

							}


				}else{

					$message=["no_notification"];

					return json_encode($message);

				}

				

		}else{

			$message=['Invalid_user'];

			return $message;

		}

	}
}