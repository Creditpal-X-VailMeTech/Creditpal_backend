<?php
require_once "load_env.php";

require_once "app_classes/Class_app_decode_token.php";

class Outstanding_loan_repay extends Db_connect{
	
	//property
	private $amount;
	private $bank;
	private $acct_number;
	private $note;
	private $ref;



	//constructor

	public function __construct(int $amount,$bank,$acct_number,$note,$ref){

		$this->amount=$amount;
		$this->bank=$bank;
		$this->acct_number=$acct_number;
		$this->note=$note;
		$this->ref=$ref;

	}




	//Public method for validating token
	public function token_verification(){


		//calling the jwt class
		$verify_token=new Jwt_decoded;

		if ($verify_token->decoded()) {

			return $verify_token->decoded();

		}


	}






	//Public Method for handling error

	public function error_handler_repay(){

		if (empty($this->amount)) {
			
			return true;
		}

	}






	//public method to check if the user exist
	public function check_user(){
			$user=$this->token_verification();

			$sql_repay="SELECT * FROM users WHERE username=:username;";

			$result_repay=parent::conn()->prepare($sql_repay);

			$result_repay->bindParam(':username',$user);

			$result_repay->execute();

			if ($result_repay->rowCount() === 0) {

				return true;
			}



	}






	//public method to confirm sufficient balance
	public function check_balance(){
			$user=$this->token_verification();

			$sql_repay="SELECT * FROM users WHERE username=:username;";

			$result_repay=parent::conn()->prepare($sql_repay);

			$result_repay->bindParam(':username',$user);

			$result_repay->execute();

			if ($result_repay->rowCount() > 0) {

				if ($rows=$result_repay->fetch()) {
					



	//Getting the wallet information of the user And Static bank details
								$data=new Load_me;


							$curl = curl_init();

							curl_setopt_array($curl, array(
 							 CURLOPT_URL => "https://api.flutterwave.com/v3/payout-subaccounts/".$rows['acct_reference']."/static-account",
 							 CURLOPT_RETURNTRANSFER => true,
 							 CURLOPT_ENCODING => "",
 							 CURLOPT_MAXREDIRS => 10,
 							 CURLOPT_TIMEOUT => 0,
 							 CURLOPT_FOLLOWLOCATION => true,
 							 CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
 							 CURLOPT_CUSTOMREQUEST => "GET",
  
 							 CURLOPT_HTTPHEADER => array(
 							       "Content-Type: application/json",
 							       'Accept: application/json',
 							   "Authorization: Bearer ".$data->display_me()['key_me'].""
							),
							));

							$response = json_decode(curl_exec($curl),true);

							curl_close($curl);






						//Fetching the available balance of the user

						$curl = curl_init();

					curl_setopt_array($curl, array(
  					CURLOPT_URL => "https://api.flutterwave.com/v3/payout-subaccounts/".$rows['acct_reference']."/balances",
  					CURLOPT_RETURNTRANSFER => true,
  					CURLOPT_ENCODING => "",
  					CURLOPT_MAXREDIRS => 10,
  					CURLOPT_TIMEOUT => 0,
  					CURLOPT_FOLLOWLOCATION => true,
  					CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  					CURLOPT_CUSTOMREQUEST => "GET",
 
  					CURLOPT_HTTPHEADER => array(
  					      "Content-Type: application/json",
  					      'Accept: application/json',
  					  "Authorization: Bearer ".$data->display_me()['key_me'].""
  					),
					));

				$responded = json_decode(curl_exec($curl),true);

					curl_close($curl);





					if ($responded['status'] === "success") {
						// code...
					

							//Checking if the user has sufficient balance
							if (floor($responded['data']['available_balance']) > $this->amount && floor($responded['data']['available_balance']) <= 0) {
						

								return true;

							}

					}elseif ($responded['status'] === "error") {
						
								$error=["error"=>" An error occured"];

								return json_encode($error);
								die();	
					}
				}


			}



	}









	//Public Method for checking if calculation

	public function repay_loan(){

			$user=$this->token_verification();

			$date=date('Y-m-d H:i:s');


			$sql_repay="SELECT * FROM users WHERE username=:username;";

			$result_repay=parent::conn()->prepare($sql_repay);

			$result_repay->bindParam(':username',$user);

			$result_repay->execute();

			if ($result_repay->rowCount() > 0) {
				
				if ($rows=$result_repay->fetch()) {
					
						$outstanding=$rows['user_outstanding_loan'];

				

				//Section for calcultion

				if ($outstanding > 0 && $this->amount >= 100 && $this->amount <= $outstanding) {

					

				//Repaying loan to the admin account test
					$data=new Load_me;


					$curl = curl_init();

					curl_setopt_array($curl, array(
 					 CURLOPT_URL => "https://api.flutterwave.com/v3/transfers",
					  CURLOPT_RETURNTRANSFER => true,
					  CURLOPT_ENCODING => "",
					  CURLOPT_MAXREDIRS => 10,
					  CURLOPT_TIMEOUT => 0,
					  CURLOPT_FOLLOWLOCATION => true,
					  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					  CURLOPT_CUSTOMREQUEST => "POST",
					  CURLOPT_POSTFIELDS =>'{
					
					    "account_bank": "'.$this->bank.'",
					  "account_number": "'.$this->acct_number.'",
					  "amount": "'.$this->amount.'",
					  "narration": "'.$this->note.'",
					  "currency": "NGN",
					  "reference": "'.$this->ref.'",
					  "debit_currency": "NGN",
					 "debit_subaccount": "'.$rows['acct_reference'].'"

				}',
				  CURLOPT_HTTPHEADER => array(
				        "Content-Type: application/json",
				        'Accept: application/json',
				    "Authorization: Bearer ".$data->display_me()['key_me'].""
				  ),
				));

				$response = json_decode(curl_exec($curl),true);

				curl_close($curl);





					//Updating the database

					if ($response['status'] === "success") {
						// code...
					

					
					$subtraction=$outstanding - $this->amount;


					$update_loan="UPDATE users SET user_outstanding_loan=:outstand WHERE username=:username LIMIT 1;";

					$result_loan=$this->conn()->prepare($update_loan);

					$result_loan->bindParam(":outstand",$subtraction);
					$result_loan->bindParam(":username",$user);


					//closing the database


					if ($result_loan->execute()) {
						
						$update_loan=null;
						$result_loan=null;
					}


					//Updating the table for transaction

					$tran_type="Repaid loan";
					$status="completed";

					$sql_trans="INSERT INTO transactions(transaction_type,transaction_amount,transaction_user,transaction_status,transaction_date,ref)VALUES(:type,:amount,:username,:status,:timing,:ref);";

					$result_sql= parent::conn()->prepare($sql_trans);


					$result_sql->bindParam(":type",$tran_type);
					$result_sql->bindParam(":amount",$this->amount);
					$result_sql->bindParam(":username",$user);
					$result_sql->bindParam(":status",$status);
					$result_sql->bindParam(":timing",$date);
					$result_sql->bindParam(":ref",$this->ref);
				


					//closing the database

					if ($result_sql->execute()) {
						
						$sql_trans=null;
						$result_sql=null;
					}





					$sql_paid="INSERT INTO repay_loan(user_account,amount_paid,paid_date)VALUES(:username,:amount,:dating);";

					$result_sqls= parent::conn()->prepare($sql_paid);
					$result_sqls->bindParam(":username",$user);
					$result_sqls->bindParam(":amount",$this->amount);
					$result_sqls->bindParam(":dating",$date);
				


					//closing the database

					if ($result_sqls->execute()) {
						
						$sql_paid=null;
						$result_sqls=null;
					}



					return true;

					
				}elseif ($response['status'] === "error") {
						
								$error=["error"=>" An error occured"];

								return json_encode($error);
								die();	
				}


				}//if calc

				}//if fetch



			}

		

	}



}