<?php

require_once "app_classes/class_app_email_verification.php";


class Request_reset_password extends Db_connect{


	//properties

	private $email;



	//constructor
	public function __construct($email){

		$this->email=$email;

	}




	//Checking if the field is empty
	public function error_handle_request(){

		if(empty($this->email)){

			return true;
		}

	}






	//checking if the user exist in the database
	public function validate_user(){

		$sql="SELECT * FROM users WHERE username=:username;";
		$result=parent::conn()->prepare($sql);

		$result->bindParam(":username",$this->email);
		$result->execute();

		if ($result->rowCount() === 0) {
			
			return true;
		}


	}






	//checking if the user exist in the database
	public function email_validated_user(){

		$verification_code=random_int(1000, 9000);

		$email_invoke=new Email_verification($this->email,$verification_code);


		$sql="SELECT * FROM users WHERE username=:username;";
		$result=parent::conn()->prepare($sql);

		$result->bindParam(":username",$this->email);
		$result->execute();


		if ($result->rowCount() > 0) {
			
			if ($rows=$result->fetch()) {


				$sql_update="UPDATE users SET reset_password=:reset_password WHERE username=:username LIMIT 1;";
				$result_update=parent::conn()->prepare($sql_update);

				$result_update->bindParam(":reset_password",$verification_code);
				$result_update->bindParam(":username",$this->email);

				if ($result_update->execute()) {
					

					$title="Reset Password";
					$email_invoke->email_reset_pin($title);


					$sql_update=null;
					$result=null;
					

					return true;
				}
				

			}
		}


	}


}