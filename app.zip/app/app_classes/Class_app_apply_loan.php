<?php
require_once "app_classes/Class_app_decode_token.php";


class Apply_loan extends Db_connect{
	
	//properties

	private $marital_status;
	private $loan_amount;
	private $education;
	private $occupation;
	private $state;
	private $home_address;
	private $monthly_income;
	private $guarantor_name;
	private $guarantor_phone;
	private $guarantor_state;
	private $guarantor_home_address;
	

		
	//constuctor
	public function __construct($marital_status,int $loan_amount,$education,$occupation,$state,$home_address,int $monthly_income,$guarantor_name,$guarantor_phone,$guarantor_state,$guarantor_home_address){


		$this->marital_status=$marital_status;
		$this->loan_amount=$loan_amount;
		$this->education=$education;
		$this->occupation=$occupation;
		$this->state=$state;
		$this->home_address=$home_address;
		$this->monthly_income=$monthly_income;
		$this->guarantor_name=$guarantor_name;
		$this->guarantor_phone=$guarantor_phone;
		$this->guarantor_state=$guarantor_state;
		$this->guarantor_home_address=$guarantor_home_address;


	}




		//Public method for validating token
	public function token_verification(){


		//calling the jwt class
		$verify_token=new Jwt_decoded;

		if ($verify_token->decoded()) {

			return $verify_token->decoded();

		}


	}



	//public method

	public function error_handle_loan_apply(){


		if(empty($this->marital_status) || empty($this->loan_amount) || empty($this->education) || empty($this->occupation) || empty($this->state) || empty($this->home_address) || empty($this->monthly_income) || empty($this->guarantor_name) || empty($this->guarantor_phone) || empty($this->guarantor_state) || empty($this->guarantor_home_address)){


			return true;
		}



	}




	//check user
	public function check_user(){
		 $user=$this->token_verification();

		$sql="SELECT * FROM users WHERE username=:username;";
			$result=parent::conn()->prepare($sql);
			$result->bindParam(":username",$user);

			$result->execute();


			if ($result->rowCount() === 0) {

				return true;

			}


	}




	//public method

	public function send_loan_request_to_admin(){

				 $user=$this->token_verification();

			$date=date('Y-m-d');
			$time=date('H:i:s');


				//INSERT THE DATA INTO THE DATABASE
		$sql="INSERT INTO loan(account_user,marital_status,loan_amount,education,occupation,state,home_address,monthly_income,guarantor_name,guarantor_phone,guarantor_state,guarantor_home_address,date_applied,loan_time)Values(?,?,?,?,?,?,?,?,?,?,?,?,?,?);";

		$result=parent::conn()->prepare($sql);


		
		//Checking if the data has been stored in the database
		if ($result->execute([$user,$this->marital_status,$this->loan_amount,$this->education,$this->occupation,$this->state,$this->home_address,$this->monthly_income,$this->guarantor_name,$this->guarantor_phone,$this->guarantor_state,$this->guarantor_home_address,$date,$time])) {
				

				//Then email the admin for him to know someone applied for loan

				$to="email@gmail.com";
				$subject="Loan Application";
				$body="Yo someone applied for loan";
				$header="From:<noreply@creditpal.com.ng>" . "\r\n";
				$header.="MIME-VERSION: 1.0" . "\r\n";
				$header.="Content-type:text/html;meta-charset=UFT-8" . "\r\n";

				mail($to, $subject, $body,$header);

				$sql=null;
				$result=null;

				return true;



		}


		
		

	}







}