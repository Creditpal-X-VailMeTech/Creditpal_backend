<?php
require_once "load_env.php";

class Db_connect{

	//Constructor

		private $dblocalhost;
		private $dbusername;
		private $dbpwd;
		private $dbname;



	//Methode

	protected function conn(){

			$data=new Load_me;


			$this->dblocalhost="localhost";
			$this->dbusername="".$data->display_me()['user_me']
."";
			$this->dbpwd="".$data->display_me()['pwd_me']
."";
			$this->dbname="".$data->display_me()['host_me']
."";




		//Applying the try and catch statment

		try {
			$dns="mysql:host=".$this->dblocalhost.";dbname=".$this->dbname."";
			$pdo= new PDO($dns,$this->dbusername,$this->dbpwd);

			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);	

			return $pdo;

			
			
		} catch (PDOException $e) {

			die("Connection Failed:" . $e->getMessage());
			
		}


	}



}