<?php



class Email_verification{

	//properties
	private $uid;
	private $auth_code;

	//constructor 
	public function __construct($uid,$auth_code){

		$this->uid=$uid;
		$this->auth_code=$auth_code;

	}


	//pulic method for email message
	public function email_message(){


		$to=$this->uid;
		$title="Email Verification";
		$body="

				Your verification code ".$this->auth_code."


			";

		$header="From:<noreply@creditpal.com.ng>" . "\r\n";	
		$header.="MIME-Version:1.0" . "\r\n";
		$header.="Content-type:text/html;meta-charset=UTF-8" . "\r\n";

		mail($to, $title, $body, $header);



	}





	//pulic method for email to reset pin
	public function email_reset_pin($title){


		$to=$this->uid;
		$title=$title;
		$body="

				Your verification code ".$this->auth_code."


			";

		$header="From:<noreply@creditpal.com.ng>" . "\r\n";	
		$header.="MIME-Version:1.0" . "\r\n";
		$header.="Content-type:text/html;meta-charset=UTF-8" . "\r\n";

		mail($to, $title, $body, $header);

		

	}




}