<?php
require_once "load_env.php";

class Actual_app_register extends Db_connect{

	//Method to signup the user 
	public function signup($bvn,$uid,$pwd,$first_name,$last_name,$initiated_reference,$phone){


		$data=new Load_me;

		$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.flutterwave.com/v3/payout-subaccounts",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS =>'{

  "account_name": "'.$first_name.' '.$last_name.'",
  "email": "'.$uid.'",
  "mobilenumber": "'.$phone.'",
  "country": "NG"

}',
  CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        'Accept: application/json',
    "Authorization: Bearer ".$data->display_me()['key_me'].""
  ),
));

$response = json_decode(curl_exec($curl),true);

curl_close($curl);
	
	
if($response['status'] === "success"){
//Insert datat into the database


		$status="enabled";
		$verification_code=random_int(1000, 9000);
 		$user_image="https://www.creditpal.com.ng/app/default.jpg";

		$sql_register="INSERT INTO users(username,password,firstname,lastname,initiated_reference,phone,barter_id,acct_reference,identity_number,account_status,verification_code,user_image,user_bank,user_account_number)Values(:username,:password,:firstname,:lastname,:initiated_reference,:phone,:barter_id,:acct_reference,:identity_number,:account_status,:verification_code,:user_image,:user_bank,:account_number);";

		$sql_result=parent::conn()->prepare($sql_register);

		$sql_result->bindParam(":username",$uid);
		$sql_result->bindParam(":password",$pwd);
		$sql_result->bindParam(":firstname",$first_name);
		$sql_result->bindParam(":lastname",$last_name);
		$sql_result->bindParam(":initiated_reference",$initiated_reference);
		
		$sql_result->bindParam(":phone",$phone);
		$sql_result->bindParam(":barter_id",$response['data']['barter_id']);
		$sql_result->bindParam(":acct_reference",$response['data']['account_reference']);
		$sql_result->bindParam(":identity_number",$bvn);
		$sql_result->bindParam(":account_status",$status);
		$sql_result->bindParam(":verification_code",$verification_code);
		$sql_result->bindParam(":user_image",$user_image);
		$sql_result->bindParam(":user_bank",$response['data']['bank_name']);
		$sql_result->bindParam(":account_number",$response['data']['nuban']);
		

		//Closing the connection to database

		if ($sql_result->execute()) {

		$email_inbox=new Email_verification($uid,$verification_code);

			$email_inbox->email_message();
			
			$sql_register=null;
			$sql_result=null;

			return true;
		}
}elseif($response['status'] === "error"){
    
	$message=[

				"message" => "An error occured during signup"

			];
			
			
			echo json_encode($message,JSON_NUMERIC_CHECK);			
			die();
			
}
	 }
}