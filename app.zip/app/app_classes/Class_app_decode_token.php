<?php


require_once "app_classes/class_app_jwt.php";



class Jwt_decoded{

	public function decoded(){

			$verified=new JTW;

			if ($verified->jwt()) {
				
				//Get the JWT token which is in returned as json encoded format

				$decode_encryption=json_decode($verified->jwt(),true);


				//Get the token itself, and split it into an array
				$explode_token=explode(".", $decode_encryption['token']);

				//Get the payloader from the spit arrary
				$get_payload=$explode_token[1];


				//Decode the payloader using the json decode base64, and pass on the true value to get the user's details
				$get_data=json_decode(base64_decode($get_payload),true);

				//Then return the user's value and query the database
				return $get_data['username'];
			}
	}


}