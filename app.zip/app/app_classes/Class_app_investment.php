<?php

require_once "app_classes/Class_app_decode_token.php";


class Investment_plan extends Db_connect{



		//Public method for validating token
	public function token_verification(){


		//calling the jwt class
		$verify_token=new Jwt_decoded;

		if ($verify_token->decoded()) {

			return $verify_token->decoded();

		}


	}




		//public method to validate the code submitted to the users email
	public function validate(){
		
		$verify_user=$this->token_verification();


		$sql="SELECT * FROM users WHERE username=:username";
		$result=parent::conn()->prepare($sql);

		$result->bindParam(":username",$verify_user);

		$result->execute();

		if ($result->rowCount() === 0) {

			return true;

		}

	}






	//Method to display the investment plan to the user
	public function view_investment_plan(){


		$verify_user=$this->token_verification();


		//Checking if the username in the JWT class matches with the one passed with the token


			//Getting the invesment plan
			$sql="SELECT * FROM investment WHERE account_user=:username;";
			$sql_result=parent::conn()->prepare($sql);

			$sql_result->bindParam(":username",$verify_user);

			$sql_result->execute();

			if ($sql_result->rowCount() > 0) {

				if ($rows=$sql_result->fetch(PDO::FETCH_ASSOC)) {
						
						$details=["investment"=>$rows];

					echo json_encode($details,JSON_NUMERIC_CHECK);

					die();

				}

				
			}else{

				$message=["message"=>"You don't have any investment"];

				return json_encode($message);

				die();
			}




	}



}