<?php

require_once realpath(__DIR__.'/vendor/autoload.php');


class Load_me{

 public function display_me(){
  $dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
  $dotenv->safeLoad();;

  $key=$_ENV['SECRET_KEY'];
  $token=$_ENV['API_TOKEN'];
  $hostusername=$_ENV['HOST_USERNAME'];
  $hostpwd=$_ENV['HOST_PWD'];
  $hostname=$_ENV['HOST_NAME'];


  return $confidential=[

      "key_me"=>$key,
      "token_me"=>$token,
      "user_me"=>$hostusername,
      "pwd_me"=>$hostpwd,
      "host_me"=>$hostname,

    ];


 }


}


