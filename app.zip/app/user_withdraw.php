<?php

header("Content-type: application/json;meta-charset=UTF-8");


require_once "app_classes/Config_db.php";
require_once "app_classes/config_session.php";
require_once "app_classes/Class_app_withdraw_to_bank.php";

if ($_SERVER['REQUEST_METHOD'] === "POST") {
	

	$detail=json_decode(file_get_contents("php://input"),true);

	$amount=$detail['amount'];
	$acct_number=$detail['acct_number'];
	$bank=$detail['bank'];
	$note=$detail['note'];
	$pin=$detail['login_pin'];
	

	if ($amount === "") {
		
		$amount=0;
	}

	

	$verify=new Withdraw_to_bank($amount,$acct_number,$bank,$note,$pin);


	//Section for checking if the field is empty

	if ($verify->empty_error_check()) {
		
		$error=["error"=>"Empty field"];

		echo json_encode($error,JSON_NUMERIC_CHECK);
		die();
	}


	//Checking if the user is authorized to access the page

	if (!$verify->token_verification()) {
		
		$error=["error"=>"Expired or invalid token"];

		echo json_encode($error,JSON_NUMERIC_CHECK);
		die();

	}


	//Check if the user is valid
	if ($verify->check_user()) {
		
		$error=["error"=>"User does not exist"];

		echo json_encode($error,JSON_NUMERIC_CHECK);
		die();

	}


	//Check if the user is valid
	if (!$verify->check_login_pin()) {
		
		$error=["error"=>"invalid pin"];

		echo json_encode($error,JSON_NUMERIC_CHECK);
		die();

	}





	if(!$verify->check_balance()){

		$error=["message"=>"Insufficient fund"];

		echo json_encode($error,JSON_NUMERIC_CHECK);
		die();
	}



	//IF everything is ok then insert into the database
	if (!$verify->empty_error_check() && $verify->token_verification() && !$verify->check_user() && $verify->check_login_pin() && $verify->check_balance() && $verify->verify_balance_and_withdraw()) {
		


		die();

	}


}else{
	$error=["error"=>"Invalid access"];

		echo json_encode($error,JSON_NUMERIC_CHECK);
		die();
}