<?php

header("Content-type: application/json;meta-charset=UTF-8");

require_once "app_classes/Config_db.php";
require_once "app_classes/config_session.php";
require_once "app_classes/Class_app_add_balance.php";


if ($_SERVER['REQUEST_METHOD'] === "POST") {

	//Getting the details from the app
	$details=json_decode(file_get_contents("php://input"),true);

	$amount=$details['amount'];

	if ($amount == "") {
		$amount=0;
	}


	//calling the className for the transaction
	$deposit=new Add_balance($amount);


	//Checking if the required parameters are empty
	if ($deposit->error_handle_deposits()) {
		
		$error=["error"=>"Field is empty"];

		echo json_encode($error);
		die();
	}


	//checking if the token used is valid or expired
	if (!$deposit->token_verification()) {
		
		$error=["error"=>"Expired or invalid token"];

		echo json_encode($error);
		die();
	}


	//Checking if the user is valid
	if($deposit->validate_user()){

		$error=["error"=>"User does not exist"];

		echo json_encode($error);
		die();

	}



	//Checking if the payment was successful
	if ($deposit->process_payment() && $deposit->token_verification() && !$deposit->validate_user()) {
		
			$message=["message"=>"Deposit successful"];

			echo json_encode($message);
			die();

	}

	
}else{
		$message=["error"=>'Invalid access to the page'];

	echo json_encode($message);
	die();
}
