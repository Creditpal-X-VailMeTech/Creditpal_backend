<?php

header("Content-type: application/json;meta-charset=UTF-8");

require_once "app_classes/Config_db.php";
require_once "app_classes/config_session.php";
require_once "app_classes/Class_app_apply_loan.php";


if ($_SERVER['REQUEST_METHOD'] === "POST") {

	//Getting the input details

	$details=json_decode(file_get_contents("php://input"),true);

	$marital_status=$details['marital_status'];
	$loan_amount=$details['loan_amount'];
	$education=$details['education'];
	$occupation=$details['occupation'];
	$state=$details['state'];
	$home_address=$details['home_address'];
	$monthly_income=$details['monthly_income'];
	$guarantor_name=$details['guarantor_name'];
	$guarantor_phone=$details['guarantor_phone'];
	$guarantor_state=$details['guarantor_state'];
	$guarantor_home_address=$details['guarantor_home_address'];


	if ($loan_amount === "") {
		$loan_amount = 0;
	}

	if ($monthly_income === "") {
		$monthly_income=0;
	}


	//Get the class name to process the application

	$apply_loan=new Apply_loan($marital_status,$loan_amount,$education,$occupation,$state,$home_address,$monthly_income,$guarantor_name,$guarantor_phone,$guarantor_state,$guarantor_home_address);



	//checking if the provided token is still valid
	if (!$apply_loan->token_verification()) {

		$error=["error"=>"Expired token or Invalid"];

		echo json_encode($error);
		die();
	}
	


	//Checking if any of the required parameter is empty

	if ($apply_loan->error_handle_loan_apply()) {
		
		$error=["error"=>"Field is empty"];

		echo json_encode($error);
		die();
	}





	//Checking if the required data has been keyed into the database
	if ($apply_loan->check_user()) {
		
		$error=["error"=>"User doesn't exist"];

		echo json_encode($error);
		die();
	}


	//Checking if the applicaton is successful

	try {
		
		if ($apply_loan->send_loan_request_to_admin() && $apply_loan->token_verification() && !$apply_loan->error_handle_loan_apply() && !$apply_loan->check_user()) {
			
			$message=['message'=>"Your application has been submited and pending approval from the admin"];

			echo json_encode($message);
			die();

		}elseif (!$apply_loan->send_loan_request_to_admin()) {
			

			$message=['message'=>"An Error has occured, please try again"];

			echo json_encode($message);
			die();

		}



	} catch (PDOException $e) {
		
		die("Connection: " . $e->getMessage());
	}

}else{

	$message=["error"=>'Invalid access to the page'];

	echo json_encode($message);
	die();
}