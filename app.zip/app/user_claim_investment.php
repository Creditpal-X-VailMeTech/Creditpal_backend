<?php

header("Content-type: application/json;meta-charset=UTF-8");


require_once "app_classes/Config_db.php";
require_once "app_classes/config_session.php";
require_once "app_classes/Class_app_claim_investment.php";


if ($_SERVER['REQUEST_METHOD'] === "POST") {
	
	$detail=json_decode(file_get_contents("php://input"),true);

	$id=$detail['id'];

	if ($id === "") {
		$id=0;
	}

	$class_redeem=new Redeem_investment($id);

	//checking if the field is empty
	if($class_redeem->error_handle_request()){

		$error=[
			"error"=>"Empty Field"
		];
		
		echo json_encode($error,JSON_NUMERIC_CHECK);
		die();
	}



	//Checking if the user is still legit
	if ($class_redeem->check_user()) {
		$error=[
			"error"=>"Invalid user",
		];
		
		echo json_encode($error,JSON_NUMERIC_CHECK);
		die();
	}


	//Proceed to check if the investment date is due
	try {

		if (!$class_redeem->error_handle_request() && !$class_redeem->check_user() && $class_redeem->check_user_and_investment_id()) {
			
			$message=["message"=>"Request to reedem your investment is being proccessed you will be notified once your balance is credited"];

			echo json_encode($message,JSON_NUMERIC_CHECK);
			
			die();

		}
		
	} catch (PDOException $e) {
		
		die("Connection:" . $e->getMessage());
	}


}else{
		$error=["error"=>"Error Invalid access"];

		echo json_encode($error,JSON_NUMERIC_CHECK);

		die();
}