<?php

header("Content-type: application/json;meta-charset=UTF-8");

require_once "app_classes/Config_db.php";
require_once "app_classes/config_session.php";
require_once "app_classes/Class_app_notification.php";

if ($_SERVER['REQUEST_METHOD'] === "POST") {
	
	$details=json_decode(file_get_contents("php://input"),true);

	$uid=$details['username'];

	//GETTING THE CLASS NAME
	$check=new Notification($uid);


	//Checking is the user has a valid token

	if ($check->get_selected_notification() == "Invalid_user") {
		
		$error=["Invalid token or expired token"];

		return json_encode($error);
		die();	
	}


	//Checking if there is any notification for the user
	if ($check->get_selected_notification() == "no_notification") {

			$message=["You don't have any notification at the moment"];

		return json_encode($message);
		die();	
		
		
	}


	if ($check->get_selected_notification() != "Invalid_user" && $check->get_selected_notification() != "no_notification") {
		
		$check->get_selected_notification();
		die();

	}


}else{
	$message=["Invalid access"];

	return json_encode($message);
	die();	

}