<?php

header("Content-type: application/json;meta-charset=UTF-8");

require_once "app_classes/Config_db.php";
require_once "app_classes/config_session.php";
require_once "app_classes/Class_app_register.php";
require_once "app_classes/Class_app_actual_register.php";
require_once "app_classes/Class_app_email_verification.php";

if ($_SERVER['REQUEST_METHOD'] === "POST") {
	
	//Getting data array from the app
	$inputs=json_decode(file_get_contents("php://input"),true);


	$first_name=$inputs['first_name'];
	$last_name=$inputs['last_name'];
	$uid=$inputs['username'];
	$bvn=$inputs['identity_number'];
	$pwd=$inputs['pwd'];

	//Calling the class to handle the errors

	$cross_check=new App_register_user($first_name,$last_name,$bvn,$uid,$pwd);
	$signed=new Actual_app_register;


	//checking for empty fields
	if ($cross_check->handle_user_error()) {
		
		$error=["error"=>"input field empty",
				"first_name"=>$first_name,
				"last_name"=>$last_name,
				"uid"=>$uid,
				"bvn"=>$bvn,
				"pwd"=>$pwd
				];

				echo json_encode($error,JSON_NUMERIC_CHECK);

		die();
	}


//checking if Character

	if ($cross_check->character()) {
		
		$error=["error"=>"Invalid character in the name field",
				"first_name"=>$first_name,
				"last_name"=>$last_name,
				"uid"=>$uid,
				"bvn"=>$bvn,
				"pwd"=>$pwd

				];

				echo json_encode($error,JSON_NUMERIC_CHECK);

		die();
	}




	//Checking for email validation

	if ($cross_check->validate_email()) {
		
		$error=["error"=>"Invalid Email",

				"first_name"=>$first_name,
				"last_name"=>$last_name,
				"uid"=>$uid,
				"bvn"=>$bvn,
				"pwd"=>$pwd
			];

				echo json_encode($error,JSON_NUMERIC_CHECK);

		die();
	}

	//checking if user already exist in the database

	if ($cross_check->user_already_exist()) {
		
		$error=["error"=>"Email already exist",

			"first_name"=>$first_name,
				"last_name"=>$last_name,
				"uid"=>$uid,
				"bvn"=>$bvn,
				"pwd"=>$pwd

				];

				echo json_encode($error,JSON_NUMERIC_CHECK);

		die();
	}





	//Checking if the user entered a valid bvn or nin
	if ($cross_check->verify_bvn()['status'] === "error") {
		
		$error=["error"=>"Invalid bvn",
				"first_name"=>$first_name,
				"last_name"=>$last_name,
				"uid"=>$uid,
				"bvn"=>$bvn,
				"pwd"=>$pwd

				];
				echo json_encode($error,JSON_NUMERIC_CHECK);

		die();
	}



	//Checking bvn permission
	if ($cross_check->verify_bvn_consent()['status'] === "error") {
		
		$error=["error"=>"Invalid bvn",
				"first_name"=>$first_name,
				"last_name"=>$last_name,
				"uid"=>$uid,
				"bvn"=>$bvn,
				"pwd"=>$pwd

				];
				echo json_encode($error,JSON_NUMERIC_CHECK);

		die();
	}

try{

		//Then sign the user
		if($signed->signup($bvn,$uid,$cross_check->encrypt_pwd(),$first_name,$last_name,$cross_check->verify_bvn_consent()['data']['reference'],$cross_check->verify_bvn_consent()['data']['bvn_data']['phoneNumber1'])){

			

				$message=[

				"message" => "Successful",
				"user" => $uid

			];


			echo json_encode($message,JSON_NUMERIC_CHECK);			
			die();



		}

		
	}catch(PDOException $e){

			die("Connection:" . $e->getMessage());
	}	
	



}else{

	$error=["error"=>"Invalid access"];
				echo json_encode($error,JSON_NUMERIC_CHECK);

		die();

}