<?php


header("Content-type: application/json;meta-charset=UTF-8");

require_once "app_classes/Config_db.php";
require_once "app_classes/config_session.php";
require_once "app_classes/Class_app_create_investment.php";


if ($_SERVER['REQUEST_METHOD'] === "POST") {
	
	$details=json_decode(file_get_contents("php://input"),true);

	$i_name=$details['investment_name'];
	$i_plan=$details['investment_plan'];
	$i_duration=$details['investment_duration'];
	$i_amount=$details['investment_amount'];
	$i_estimated_returns=$details['investment_estimated_returns'];
	$note=$details['note'];
	$pay_day=$details['pay_day'];
	$bank="Access Bank";
	$acct_number="0690000040";
	$ref=md5(time());


	if ($i_amount === "") {
		
		$i_amount=0;
	}

	if ($i_estimated_returns === 0) {
		
		$i_estimated_returns=0;
	}
	

	//Calling the user investment class
	$investment=new Create_investment($i_name,$i_plan,$i_duration,$i_amount,$i_estimated_returns,$note,$pay_day,$bank,$acct_number,$ref);



	if (!$investment->token_verification()) {
		
		$error=["error"=>"Invalid token to access this page"];

		echo json_encode($error);

		die();
	}

	if ($investment->error_handle_investment()) {
		
		$error=["error"=>"Field is empty"];

		echo json_encode($error);

		die();
	}


	

	if ($investment->check_user()) {
		
		$error=["error"=>"User does not exist"];

		echo json_encode($error);

		die();
	}



	try {

		if ($investment->create_investment_plan() && !$investment->check_user() && $investment->token_verification()) {
		


			}

	} catch (PDOException $e) {

			die("Connection:" .$e->getMessage());
			
		}



}else{

	$message=['message'=>'Invalid access'];

	echo json_encode($message);
	die();

}