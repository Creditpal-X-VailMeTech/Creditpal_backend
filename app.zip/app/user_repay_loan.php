<?php

header("Content-type: application/json;meta-charset=UTF-8");

require_once "app_classes/Config_db.php";
require_once "app_classes/config_session.php";
require_once "app_classes/Class_app_repay_loan.php";


if ($_SERVER['REQUEST_METHOD'] === "POST") {
	
	$detail=json_decode(file_get_contents("php://input"),true);

	$amount=$detail['amount'];
	$bank="Access Bank";
	$acct_number="0690000040";
	$note="Repay loan";
	$ref=md5(time());

	if ($amount === "") {
		
		$amount=0;
	}

	$verify=new Outstanding_loan_repay($amount,$bank,$acct_number,$note,$ref);

	//Checking if the required parameters are empty


	if (!$verify->token_verification()) {
		
		$error=["error"=>"Expired or Invalid token"];

		echo json_encode($error);

		die();	
	}




	if ($verify->error_handler_repay()) {
		
		$error=["error"=>"Field is empty!"];

		echo json_encode($error);

		die();	
	}



	//Checking if the user is invalid
	if ($verify->check_user()) {

		$error=["error"=>"Invalid user"];

		echo json_encode($error);
		die();	

	}


	//Checking if the user is invalid
	if ($verify->check_balance()) {

		$error=["error"=>"Insufficient Fund"];

		echo json_encode($error);
		die();	

	}





	//Checking is all the required conditions are met

	if (!$verify->error_handler_repay() && $verify->token_verification() && $verify->repay_loan() && !$verify->check_user() && !$verify->check_balance()) {
		
		$message=["message"=>"Successful"];

		echo json_encode($message);
		die();	

	}elseif (!$verify->repay_loan()) {
		
		$message=["message"=>"Invalid amount"];

		echo json_encode($message);
		die();	
	}


}else{

	$message=["error"=>"Invalid access"];

	echo json_encode($message);
	die();	

}