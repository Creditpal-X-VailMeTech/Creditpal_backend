<?php

header("Content-type: application/Json;meta-charset=UTF-8");

require_once "app_classes/Config_db.php";
require_once "app_classes/config_session.php";
require_once "app_classes/Class_app_new_pin.php";


if ($_SERVER['REQUEST_METHOD'] === "POST") {
	
	//Getting the input details via php input

	$details=Json_decode(file_get_contents("php://input"),true);


	$uid=$details['username'];
	$otp=$details['new_pin'];

	$validate=new Reset_pin($uid,$otp);


	//Checking is one of the required condition is empty

	if ($validate->error_handler()) {

		$error=[
			"error"=>"Empty Field",
			"user" => $uid
		];
		
		echo json_encode($error,JSON_NUMERIC_CHECK);
		die();
	}


	//if every requirement is met then

	if (!$validate->error_handler() && $validate->set_code()) {
		
		try {
			
			$message=["message"=>"success, please proceed to login page"];

			echo json_encode($message,JSON_NUMERIC_CHECK);

			die();

		} catch (PDOException $e) {
			die("Connection: " . $e->getMessage());
		}
		
	}






}else{
		$error=["error"=>"Error Invalid access"];

		echo json_encode($error,JSON_NUMERIC_CHECK);

		die();

}
